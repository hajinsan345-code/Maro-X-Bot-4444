module.exports = async ({ api, event }) => {
  const fs = require('fs');
  const path = require('path');
  const logger = require('./main/catalogs/IMRANC.js')

  // ── تثبيت نظام الحماية من الحظر ──────────────────────────
  try {
    const shield = require('./main/system/shield.js');
    shield.install(api);
  } catch (e) {
    logger(`shield install error: ${e.message}`, 'warn');
  }

  // ── تطبيق إعدادات FCA لحماية الكوكيز ─────────────────────
  try {
    api.setOptions({
      logLevel: "silent",
      updatePresence: false,
      selfListen: false,
      autoMarkDelivery: false,
      autoMarkRead: false,
      online: false,
      listenEvents: true,
      userAgent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    });
    logger('FCA options applied successfully', 'shield');
  } catch (e) {
    logger(`FCA options error: ${e.message}`, 'warn');
  }

  const configCustom = {
    autosetbio: {
      status: false,
      bio: `prefix : ${global.config.PREFIX}`,
      note: 'automatically change the bot bio.'
    },
    greetings: {
      status: false,
      morning: `goodmorning everyone, have a nice day.`,
      afternoon: `goodafternoon everyone, don't forget to eat your lunch.`,
      evening: `goodevening everyone, don't forget to eat.`,
      sleep: `goodnight everyone, time to sleep.`,
      note: 'greetings every morning, afternoon and evening.'
    },
    autoDeleteCache: {
      status: true,
      time: 10,
      note: 'auto delete caches every 10 minutes.'
    },
    autoRestart: {
      status: false,
      time: 40,
      note: 'periodic bot restarts every 40 minutes.'
    },
    accpetPending: {
      status: false,
      time: 10,
      note: 'approve waiting messages after 10 minutes.'
    },
    autoSaveAppstate: {
      status: true,
      time: 30,
      note: 'auto save appstate/cookies every 30 minutes.'
    },
    // ✅ جديد: حماية من الأخطاء المفاجئة
    antiCrash: {
      status: true,
      note: 'catch uncaught errors to prevent bot crash.'
    },
    // ✅ جديد: مراقبة الذاكرة
    memoryWatch: {
      status: true,
      maxRamMB: 400,
      note: 'restart if RAM exceeds limit.'
    }
  }

  function autosetbio(config) {
    if (config.status) {
      try {
        api.changeBio(config.bio, (err) => {
          if (err) return logger(`having some unexpected error : ${err}`, 'setbio');
          return logger(`changed the bot bio into : ${config.bio}`, 'setbio');
        });
      } catch (error) {
        logger(`having some unexpected error : ${error}`, 'setbio');
      }
    }
  }

  function greetings(config) {
    if (config.status) {
      try {
        const nam = [
          { timer: '5:00:00 AM', message: [`${config.morning}`] },
          { timer: '11:00:00 AM', message: [`${config.afternoon}`] },
          { timer: '6:00:00 PM', message: [`${config.evening}`] },
          { timer: '10:00:00 PM', message: [`${config.sleep}`] }
        ];
        setInterval(() => {
          const r = a => a[Math.floor(Math.random() * a.length)];
          const á = nam.find(i => i.timer == new Date(Date.now() + 25200000).toLocaleString().split(/,/).pop().trim());
          if (á) global.data.allThreadID.forEach(i => api.sendMessage(r(á.message), i));
        }, 1000);
      } catch (error) {
        logger(`having some unexpected error : ${error}`, 'greetings');
      }
    }
  }

  function autoDeleteCache(config) {
    if (config.status) {
      setInterval(async () => {
        const { exec } = require('child_process');
        exec('rm -rf ../../scripts/commands/cache && mkdir -p ../../scripts/commands/cache && rm -rf ../../scripts/events/cache && mkdir -p ../../scripts/events/cache', (error, stdout, stderr) => {
          if (error) return logger(`error : ${error}`, "cache");
          if (stderr) return logger(`stderr : ${stderr}`, "cache");
          return logger(`successfully deleted caches`, "cache");
        });
      }, config.time * 60 * 1000);
    }
  }

  function autoRestart(config) {
    if (config.status) {
      setInterval(async () => {
        logger(`auto restart is processing, please wait.`, "ryuko");
        process.exit(1);
      }, config.time * 60 * 1000);
    }
  }

  function accpetPending(config) {
    if (config.status) {
      setInterval(async () => {
        try {
          const list = [
            ...(await api.getThreadList(1, null, ['PENDING'])),
            ...(await api.getThreadList(1, null, ['OTHER']))
          ];
          if (list[0]) {
            api.sendMessage('this thread is automatically approved by our system.', list[0].threadID);
          }
        } catch (e) {
          logger(`acceptPending error: ${e.message}`, 'pending');
        }
      }, config.time * 60 * 1000);
    }
  }

  // ── حفظ الكوكيز تلقائياً ──────────────────────────────────
  function autoSaveAppstate(config) {
    if (!config.status) return;

    const appstatePath = path.join(__dirname, 'appstate.json');

    const saveNow = () => {
      try {
        const currentAppstate = api.getAppState();
        if (!currentAppstate || !Array.isArray(currentAppstate) || currentAppstate.length === 0) {
          logger('appstate is empty, skipping save', 'appstate');
          return;
        }
        const now = new Date().toISOString();
        const updated = currentAppstate.map(cookie => ({
          ...cookie,
          lastAccessed: now
        }));
        fs.writeFileSync(appstatePath, JSON.stringify(updated, null, 4), 'utf8');
        logger(`appstate saved successfully (${updated.length} cookies)`, 'appstate');
      } catch (err) {
        logger(`failed to save appstate: ${err.message}`, 'appstate');
      }
    };

    // حفظ أول مرة بعد دقيقة واحدة
    setTimeout(saveNow, 60 * 1000);
    // حفظ دوري
    setInterval(saveNow, config.time * 60 * 1000);

    logger(`auto appstate save enabled — every ${config.time} minutes`, 'appstate');
  }

  // ── ✅ جديد: حماية من الأخطاء المفاجئة ───────────────────
  function antiCrash(config) {
    if (!config.status) return;

    process.on('uncaughtException', (err) => {
      // إذا كان الخطأ متعلق بالجلسة → أعد التشغيل
      if (
        err.message.includes('login') ||
        err.message.includes('session') ||
        err.message.includes('appstate') ||
        err.message.includes('Not logged in') ||
        err.message.includes('ECONNRESET') ||
        err.message.includes('socket hang up')
      ) {
        logger(`session error detected, restarting: ${err.message}`, 'anticrash');
        setTimeout(() => process.exit(1), 3000);
      } else {
        logger(`uncaughtException: ${err.message}`, 'anticrash');
      }
    });

    process.on('unhandledRejection', (reason) => {
      logger(`unhandledRejection: ${reason}`, 'anticrash');
    });

    logger('antiCrash protection enabled', 'anticrash');
  }

  // ── ✅ جديد: مراقبة الذاكرة ───────────────────────────────
  function memoryWatch(config) {
    if (!config.status) return;

    setInterval(() => {
      const used = process.memoryUsage().heapUsed / 1024 / 1024;
      const usedMB = Math.round(used);

      if (usedMB > config.maxRamMB) {
        logger(`RAM usage too high: ${usedMB}MB — restarting...`, 'memory');
        setTimeout(() => process.exit(1), 2000);
      } else {
        logger(`RAM usage: ${usedMB}MB / ${config.maxRamMB}MB`, 'memory');
      }
    }, 10 * 60 * 1000); // فحص كل 10 دقائق

    logger(`memory watch enabled — max: ${config.maxRamMB}MB`, 'memory');
  }

  // ── تشغيل جميع الوظائف ────────────────────────────────────
  autosetbio(configCustom.autosetbio);
  greetings(configCustom.greetings);
  autoDeleteCache(configCustom.autoDeleteCache);
  autoRestart(configCustom.autoRestart);
  accpetPending(configCustom.accpetPending);
  autoSaveAppstate(configCustom.autoSaveAppstate);
  antiCrash(configCustom.antiCrash);       // ✅ جديد
  memoryWatch(configCustom.memoryWatch);   // ✅ جديد
};
