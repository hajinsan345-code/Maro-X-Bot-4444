/**
 * Admin Protect Event
 * يراقب تغييرات أدوار المشرفين في المجموعات
 * إذا نزع أحد الأدمنز مسؤولاً → يُنزع هو تلقائياً من الإدارة
 * الإعدادات محفوظة دائماً ولا تُفقد عند إعادة تشغيل البوت
 */

const persist = require("../../main/system/utils/adminProtectPersist");

module.exports.config = {
  name: "adminprotectevent",
  eventType: ["log:thread-admins"],
  version: "1.1.0",
  credits: "Maro X bot",
  description: "حماية قائمة المشرفين — من ينزع مسؤولاً يُنزع تلقائياً",
  dependencies: {}
};

module.exports.run = async function ({ api, event, Users }) {
  const { threadID, author, logMessageData } = event;

  if (!logMessageData) return;

  const adminEvent = logMessageData.ADMIN_EVENT;
  const targetID   = String(logMessageData.TARGET_ID || "");
  const actorID    = String(author || "");
  const botID      = String(api.getCurrentUserID());

  if (adminEvent !== "remove_admin") return;
  if (!actorID || !targetID) return;

  if (actorID === botID) return;

  persist.load();
  if (!global.adminProtectData) global.adminProtectData = new Map();
  const protection = global.adminProtectData.get(threadID);
  if (!protection || !protection.enabled) return;

  const botOperators = global.config?.OPERATOR || [];
  const botAdmins    = global.config?.ADMINBOT  || [];
  const isBotPrivileged =
    botOperators.includes(actorID) || botAdmins.includes(actorID);
  if (isBotPrivileged) return;

  try {
    const actorName = global.data.userName?.get(actorID)
      || (await Users.getNameUser(actorID))
      || actorID;

    const targetName = global.data.userName?.get(targetID)
      || (await Users.getNameUser(targetID))
      || targetID;

    await api.changeAdminStatus(threadID, [actorID], false);

    const warningMsg =
      `🛡️ نظام حماية المشرفين\n` +
      `${"━".repeat(28)}\n\n` +
      `⚠️ تم رصد محاولة نزع صلاحيات مشرف!\n\n` +
      `👤 المعتدي   : ${actorName}\n` +
      `🎯 الضحية    : ${targetName}\n\n` +
      `⚡ الإجراء   : تمت إزالة ${actorName} من قائمة المشرفين تلقائياً.\n\n` +
      `${"━".repeat(28)}\n` +
      `💡 لإيقاف الحماية: -adminprotect off`;

    api.sendMessage(warningMsg, threadID);

    const botAdminList = [...botOperators, ...botAdmins];
    for (const adminUID of botAdminList) {
      try {
        api.sendMessage(
          `🚨 تنبيه حماية المشرفين\n\n` +
          `المجموعة: ${threadID}\n` +
          `المعتدي : ${actorName} (${actorID})\n` +
          `الضحية  : ${targetName} (${targetID})\n\n` +
          `تم نزع صلاحيات المعتدي تلقائياً.`,
          adminUID
        );
      } catch (_) {}
    }

  } catch (err) {
    console.error("[adminprotect] خطأ أثناء نزع الصلاحيات:", err.message);
    try {
      api.sendMessage(
        `⚠️ تم رصد محاولة نزع مشرف، لكن فشل الرد التلقائي.\n` +
        `تأكد أن البوت يملك صلاحية الإدارة في المجموعة.`,
        threadID
      );
    } catch (_) {}
  }
};
