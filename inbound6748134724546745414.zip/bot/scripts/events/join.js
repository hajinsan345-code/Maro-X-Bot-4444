const axios = require("axios");
const fs = require("fs-extra");

module.exports.config = {
  name: "join",
  eventType: ["log:subscribe"],
  version: "3.5.0",
  credits: "Marwan",
  description: "نظام الترحيب الرسمي لـ Maro X System",
  dependencies: {
    "fs-extra": "",
    "axios": ""
  }
};

function ordinalSuffix(i) {
  const j = i % 10, k = i % 100;
  if (j === 1 && k !== 11) return `${i}st`;
  if (j === 2 && k !== 12) return `${i}nd`;
  if (j === 3 && k !== 13) return `${i}rd`;
  return `${i}th`;
}

module.exports.run = async function({ api, event, Threads }) {
  const { threadID } = event;
  const botID = api.getCurrentUserID();
  
  // جلب إعدادات المجموعة
  let threadData = {};
  try {
    threadData = (await Threads.getData(threadID)).data || {};
  } catch (err) { threadData = {}; }

  const prefix = global.config.PREFIX || "!";
  
  // 1. عند دخول البوت للمجموعة
  if (event.logMessageData.addedParticipants.some(p => p.userFbId == botID)) {
    const BOT_GIF = "https://i.postimg.cc/8kfQ4WTj/14a6051f40d98f3a41ad5955d59146f5.gif"; // غوجو الخاص بك
    
    try {
      await api.changeNickname(`[ ${prefix} ] • Maro X Bot`, threadID, botID);
      
      let botMsg = `─── · · ✧ · · ───\n`;
      botMsg += `  𝗠𝗔𝗥𝗢 𝗫 𝗖𝗢𝗡𝗡𝗘𝗖𝗧𝗘𝗗\n`;
      botMsg += `─── · · ✧ · · ───\n\n`;
      botMsg += `✅ تـم تـفـعـيـل الـنـظـام بـنـجـاح\n`;
      botMsg += `📝 لـرؤية الأوامر اكتب: ${prefix}help\n\n`;
      botMsg += `━━━━━━━━━━━━━━━\n`;
      botMsg += `  𝗗𝗘𝗩𝗘𝗟𝗢𝗣𝗘𝗗 𝗕𝗬 𝗠𝗔𝗥𝗪𝗔𝗡`;

      const gifResp = await axios.get(BOT_GIF, { responseType: "stream" });
      return api.sendMessage({ body: botMsg, attachment: gifResp.data }, threadID);
    } catch (e) { console.error(e); }
  } 
  
  // 2. عند دخول أعضاء جدد
  else {
    try {
      const addedUsers = event.logMessageData.addedParticipants;
      const threadInfo = await api.getThreadInfo(threadID);
      const threadName = threadInfo.threadName || "المجموعة";
      const memCount = threadInfo.participantIDs.length;

      let mentions = [], names = [];
      for (let user of addedUsers) {
        mentions.push({ tag: user.fullName, id: user.userFbId });
        names.push(user.fullName);
      }

      let welcomeMsg = `─── · · ✧ · · ───\n`;
      welcomeMsg += `  𝗪𝗘𝗟𝗖𝗢𝗠𝗘 𝗧𝗢 𝗦𝗬𝗦𝗧𝗘𝗠\n`;
      welcomeMsg += `─── · · ✧ · · ───\n\n`;
      welcomeMsg += `أهلاً بك ${names.join(", ")} ✨\n`;
      welcomeMsg += `أنت العضو رقم ${ordinalSuffix(memCount)} في 『 ${threadName} 』\n\n`;
      welcomeMsg += `استخدم [ ${prefix}help ] لاستكشاف الأوامر\n`;
      welcomeMsg += `━━━━━━━━━━━━━━━\n`;
      welcomeMsg += `  𝗠𝗔𝗥𝗢 𝗫 𝗦𝗬𝗦𝗧𝗘𝗠`;

      // صورة الترحيب (استخدمت رابط ثابت لضمان السرعة)
      const WELCOME_IMG = "https://i.postimg.cc/8kfQ4WTj/14a6051f40d98f3a41ad5955d59146f5.gif";
      const imgStream = (await axios.get(WELCOME_IMG, { responseType: "stream" })).data;

      return api.sendMessage({
        body: welcomeMsg,
        mentions,
        attachment: imgStream
      }, threadID);
      
    } catch (e) { console.error("Welcome Error:", e); }
  }
};
