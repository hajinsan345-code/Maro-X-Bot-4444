module.exports.config = {
  name: "protectevent",
  eventType: ["log:thread-name", "log:user-nickname"],
  version: "2.1.0",
  credits: "Maro X bot",
  description: "مراقبة تغيير اسم المجموعة والكنيات واستعادتها أو مسحها تلقائياً",
  dependencies: {}
};

module.exports.run = async function ({ api, event }) {
  const threadID = String(event.threadID);

  if (!global.protectData) return;

  // ─── حماية اسم المجموعة ────────────────────────────────────────────────────
  if (event.logMessageType === "log:thread-name") {
    const protection = global.protectData.threadName.get(threadID);
    if (!protection || !protection.enabled) return;

    const newName = event.logMessageData?.name || "";
    const protectedName = protection.originalName;

    if (newName === protectedName) return;

    try {
      await api.setTitle(protectedName, threadID);
      api.sendMessage(
        `🛡️ تم رصد محاولة تغيير اسم المجموعة!\n\n⚠️ تم اكتشاف التغيير وإلغاؤه فوراً.\n✅ تمت استعادة الاسم المحمي بنجاح.`,
        threadID
      );
    } catch (e) {}
    return;
  }

  // ─── حماية الكنيات ────────────────────────────────────────────────────────
  if (event.logMessageType === "log:user-nickname") {
    const protection = global.protectData.nickall.get(threadID);
    if (!protection || !protection.enabled) return;

    const uid = String(event.logMessageData?.participant_id || "");
    const newNick = event.logMessageData?.nickname || "";

    if (!uid) return;

    // ─── وضع المسح التلقائي ─────────────────────────────────────────────────
    if (protection.mode === "clear") {
      if (newNick === "") return;
      try {
        await api.changeNickname("", threadID, uid);
        api.sendMessage(
          `🧹 تم رصد محاولة إضافة كنية!\n\n⚠️ الكنيات ممنوعة في هذه المجموعة.\n✅ تم مسح الكنية تلقائياً.`,
          threadID
        );
      } catch (e) {}
      return;
    }

    // ─── وضع الحماية بكنية محددة ─────────────────────────────────────────────
    const protectedNick = protection.desiredNick || "";
    if (newNick === protectedNick) return;

    try {
      await api.changeNickname(protectedNick, threadID, uid);
      api.sendMessage(
        `🛡️ تم رصد محاولة تغيير كنية عضو!\n\n⚠️ تم اكتشاف التغيير وإلغاؤه فوراً.\n✅ تمت استعادة الكنية المحمية بنجاح.`,
        threadID
      );
    } catch (e) {}
    return;
  }
};
