/**
 * Anti-Ban Shield — Event Monitor
 * يراقب الأخطاء ويُنبّه المسؤولين عند اكتشاف خطر
 */

module.exports.config = {
  name: "antibanevent",
  eventType: ["message", "message_reply"],
  version: "1.0.0",
  credits: "Maro X bot",
  description: "مراقبة نشاط البوت للكشف عن أنماط قد تؤدي للحظر",
  dependencies: {}
};

let lastAdminAlert = 0;

module.exports.run = async function ({ api, event }) {
  if (!global.shield || !global.shield.enabled) return;

  const s = global.shield;
  const risk = s.riskLevel;

  if ((risk === "high" || risk === "critical") && Date.now() - lastAdminAlert > 300000) {
    lastAdminAlert = Date.now();

    const RISK_EMOJI = { low: "🟢", medium: "🟡", high: "🔴", critical: "💀" };
    const emoji = RISK_EMOJI[risk] || "🔴";

    const sleepInfo = s.sleep && s.sleep.active
      ? `\n⏸️ وضع السكون: نشط\n📋 السبب: ${s.sleep.reason}`
      : "";

    const alertMsg =
      `${emoji} تنبيه نظام الحماية!\n\n` +
      `مستوى الخطر: ${risk.toUpperCase()}\n` +
      `📤 رسائل/الدقيقة: ${s.stats.sentThisMinute}/${s.limits.maxPerMinute}\n` +
      `⚠️ عدد الأخطاء: ${s.errors.count}/${s.limits.errorThreshold}` +
      sleepInfo + `\n\n` +
      `آخر خطأ: ${s.errors.history[0]?.msg || "لا يوجد"}\n\n` +
      `استخدم -antiband status للمزيد\n` +
      `استخدم -antiband wake لإيقاظ البوت`;

    const admins = global.config?.ADMINBOT || [];
    for (const uid of admins) {
      try { api.sendMessage(alertMsg, uid); } catch (_) {}
    }
  }
};
