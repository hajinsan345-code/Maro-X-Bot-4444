const fs = require("fs");
const path = require("path");
const axios = require("axios");

module.exports.config = {
  name: "speech",
  version: "2.0.0",
  permission: 0,
  credits: "Maro X bot",
  description: "Convert text to speech (supports Arabic, English, and more)",
  prefix: true,
  premium: false,
  category: "Voice",
  usages: "speech [text] or reply to a message",
  cooldowns: 5
};

module.exports.run = async ({ api, event, args }) => {
  const content = (event.type === "message_reply" && event.messageReply?.body)
    ? event.messageReply.body
    : args.join(" ");

  if (!content || !content.trim()) {
    return api.sendMessage(
      "❌ Please provide text to convert to speech.\nExample: -speech Hello everyone!",
      event.threadID,
      event.messageID
    );
  }

  const filePath = path.join(__dirname, "cache", `speech_${event.senderID}.mp3`);
  const cacheDir = path.join(__dirname, "cache");

  if (!fs.existsSync(cacheDir)) fs.mkdirSync(cacheDir, { recursive: true });

  try {
    // Detect language (basic detection: Arabic chars = ar, else en)
    const isArabic = /[\u0600-\u06FF]/.test(content);
    const lang = isArabic ? "ar" : "en";

    // Use Google Translate TTS (free, no API key needed)
    const ttsUrl = `https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=${lang}&q=${encodeURIComponent(content.substring(0, 200))}`;

    const response = await axios.get(ttsUrl, {
      responseType: "arraybuffer",
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
        "Referer": "https://translate.google.com/"
      },
      timeout: 15000
    });

    fs.writeFileSync(filePath, Buffer.from(response.data));

    api.sendMessage(
      {
        body: `🔊 Speech generated (${lang === "ar" ? "Arabic" : "English"}):\n"${content.substring(0, 80)}${content.length > 80 ? "..." : ""}"`,
        attachment: fs.createReadStream(filePath)
      },
      event.threadID,
      () => { try { fs.unlinkSync(filePath); } catch (_) {} },
      event.messageID
    );

  } catch (error) {
    console.error("Speech error:", error.message);
    api.sendMessage(
      "⚠️ Failed to generate speech. Please try again with shorter text.",
      event.threadID,
      event.messageID
    );
  }
};
