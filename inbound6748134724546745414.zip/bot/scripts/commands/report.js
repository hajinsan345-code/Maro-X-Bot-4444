module.exports.config = {
  name: "report",
  version: "3.0.0",
  permission: 0,
  credits: "Maro X bot",
  description: "نظام بلاغات متكامل: إبلاغ، طرد، وإدارة طلبات الانضمام المعلقة",
  prefix: true,
  category: "admin",
  usages: [
    "-report             — الإبلاغ عن رسالة (رد عليها)",
    "-report kick        — طرد صاحب الرسالة (رد عليها)",
    "-report kick [uid]  — طرد عضو بمعرّفه",
    "-report pending     — عرض طلبات الانضمام المعلقة",
    "-report approve [رقم] — قبول طلب بالرقم",
    "-report approve all — قبول جميع الطلبات",
    "-report autokick on/off — طرد تلقائي عند بلوغ الحد",
    "-report set [عدد]   — ضبط حد البلاغات",
    "-report list        — عرض البلاغات النشطة",
    "-report clear       — مسح البلاغات"
  ].join("\n"),
  cooldowns: 5,
  premium: false,
  dependencies: {}
};

const MAX_REPORTS = 33;
const ABUSE_LABEL = "🤬 إساءة";

if (!global.reportData) {
  global.reportData = {
    threshold: 3,
    autoKick: false,
    reports: new Map(),
    pendingCache: []
  };
}

module.exports.run = async function ({ api, event, args }) {
  const threadID  = String(event.threadID);
  const senderID  = String(event.senderID);
  const messageID = event.messageID;
  const reply     = event.messageReply;
  const sub       = (args[0] || "").toLowerCase();
  const botID     = String(api.getCurrentUserID());

  const isAdmin = (id) =>
    (global.config.ADMINBOT  || []).includes(String(id)) ||
    (global.config.OPERATOR  || []).includes(String(id)) ||
    (global.config.OWNER     || []).includes(String(id));

  const isBotGroupAdmin = async () => {
    const info = await api.getThreadInfo(threadID).catch(() => null);
    return info?.adminIDs?.some(a => String(a.id) === botID);
  };

  const notifyAdmins = async (msg) => {
    const admins = [...new Set([
      ...(global.config.ADMINBOT || []),
      ...(global.config.OPERATOR || [])
    ])];
    for (const id of admins) {
      try { await api.sendMessage(msg, id); } catch (e) {}
    }
  };

  // ─────────────────────────────────────────────
  // -report set [عدد]
  // ─────────────────────────────────────────────
  if (sub === "set") {
    if (!isAdmin(senderID))
      return api.sendMessage("⚠️ هذا الأمر للأدمن فقط.", threadID, messageID);
    const num = parseInt(args[1]);
    if (isNaN(num) || num < 1 || num > MAX_REPORTS)
      return api.sendMessage(
        `⚠️ أدخل عدداً بين 1 و ${MAX_REPORTS}.\nمثال: -report set 5`,
        threadID, messageID
      );
    global.reportData.threshold = num;
    return api.sendMessage(
      `✅ تم ضبط حد البلاغات على ${num}.\n${global.reportData.autoKick ? "⚡ الطرد التلقائي مفعّل عند الوصول لهذا الحد." : ""}`,
      threadID, messageID
    );
  }

  // ─────────────────────────────────────────────
  // -report autokick on/off
  // ─────────────────────────────────────────────
  if (sub === "autokick") {
    if (!isAdmin(senderID))
      return api.sendMessage("⚠️ هذا الأمر للأدمن فقط.", threadID, messageID);
    const action = (args[1] || "").toLowerCase();
    if (action === "on") {
      global.reportData.autoKick = true;
      return api.sendMessage(
        `⚡ تم تفعيل الطرد التلقائي.\nعند بلوغ رسالة ${global.reportData.threshold} بلاغات سيُطرد صاحبها تلقائياً.`,
        threadID, messageID
      );
    }
    if (action === "off") {
      global.reportData.autoKick = false;
      return api.sendMessage("✅ تم إيقاف الطرد التلقائي.", threadID, messageID);
    }
    return api.sendMessage(
      `⚡ حالة الطرد التلقائي: ${global.reportData.autoKick ? "مفعّل ✅" : "معطّل ❌"}\n-report autokick on  — تفعيل\n-report autokick off — إيقاف`,
      threadID, messageID
    );
  }

  // ─────────────────────────────────────────────
  // -report list
  // ─────────────────────────────────────────────
  if (sub === "list") {
    if (!isAdmin(senderID))
      return api.sendMessage("⚠️ هذا الأمر للأدمن فقط.", threadID, messageID);
    let list = "";
    let i = 1;
    for (const [, data] of global.reportData.reports) {
      if (data.threadID !== threadID) continue;
      list += `${i}. 💬 "${(data.messageBody || "(صورة/ملف)").slice(0, 60)}"\n`;
      list += `   👤 المُرسِل: ${data.senderID}\n`;
      list += `   📊 البلاغات: ${data.count}/${global.reportData.threshold} (الحد الأقصى: ${MAX_REPORTS})\n`;
      list += `   ⚠️ النوع: ${ABUSE_LABEL}\n\n`;
      i++;
    }
    if (i === 1) return api.sendMessage("📋 لا توجد بلاغات نشطة في هذه المجموعة.", threadID, messageID);
    return api.sendMessage(
      `📋 البلاغات النشطة (الحد: ${global.reportData.threshold} | الأقصى: ${MAX_REPORTS}):\n${"─".repeat(30)}\n\n${list.trim()}`,
      threadID, messageID
    );
  }

  // ─────────────────────────────────────────────
  // -report clear
  // ─────────────────────────────────────────────
  if (sub === "clear") {
    if (!isAdmin(senderID))
      return api.sendMessage("⚠️ هذا الأمر للأدمن فقط.", threadID, messageID);
    let count = 0;
    for (const [key, data] of global.reportData.reports) {
      if (data.threadID === threadID) { global.reportData.reports.delete(key); count++; }
    }
    return api.sendMessage(`✅ تم مسح ${count} بلاغ من هذه المجموعة.`, threadID, messageID);
  }

  // ─────────────────────────────────────────────
  // -report kick [uid] أو رد على رسالة
  // ─────────────────────────────────────────────
  if (sub === "kick") {
    if (!isAdmin(senderID))
      return api.sendMessage("⚠️ هذا الأمر للأدمن فقط.", threadID, messageID);

    let targetID = args[1] ? String(args[1]) : (reply ? String(reply.senderID) : null);
    if (!targetID)
      return api.sendMessage(
        "⚠️ حدّد العضو المراد طرده.\nمثال: رد على رسالته ثم اكتب -report kick\nأو: -report kick [uid]",
        threadID, messageID
      );

    if (isAdmin(targetID))
      return api.sendMessage("⚠️ لا يمكن طرد أدمن البوت.", threadID, messageID);
    if (targetID === botID)
      return api.sendMessage("⚠️ لا يمكنني طرد نفسي!", threadID, messageID);

    const canKick = await isBotGroupAdmin();
    if (!canKick)
      return api.sendMessage("⚠️ البوت ليس أدمناً في هذه المجموعة — لا يمكن الطرد.", threadID, messageID);

    try {
      await api.removeUserFromGroup(targetID, threadID);
      return api.sendMessage(`✅ تم طرد العضو ${targetID} من المجموعة.`, threadID, messageID);
    } catch (e) {
      return api.sendMessage(`⚠️ فشل الطرد: ${e.message || e}`, threadID, messageID);
    }
  }

  // ─────────────────────────────────────────────
  // -report pending
  // ─────────────────────────────────────────────
  if (sub === "pending") {
    if (!isAdmin(senderID))
      return api.sendMessage("⚠️ هذا الأمر للأدمن فقط.", threadID, messageID);
    try {
      const spam    = await api.getThreadList(100, null, ["OTHER"])   || [];
      const pending = await api.getThreadList(100, null, ["PENDING"]) || [];
      const list    = [...spam, ...pending].filter(g => g.isSubscribed && g.isGroup);

      if (list.length === 0)
        return api.sendMessage("📋 لا توجد طلبات انضمام معلقة.", threadID, messageID);

      global.reportData.pendingCache = list;

      let msg = `📋 طلبات الانضمام المعلقة (${list.length} مجموعة):\n${"─".repeat(28)}\n\n`;
      list.forEach((g, i) => {
        msg += `${i + 1}. ${g.name || "مجموعة بدون اسم"}\n   🆔 ${g.threadID}\n\n`;
      });
      msg += `${"─".repeat(28)}\n📌 للقبول: -report approve [رقم]\n📌 لقبول الكل: -report approve all`;
      return api.sendMessage(msg, threadID, messageID);
    } catch (e) {
      return api.sendMessage("⚠️ تعذّر جلب قائمة الطلبات المعلقة.", threadID, messageID);
    }
  }

  // ─────────────────────────────────────────────
  // -report approve [رقم / all]
  // ─────────────────────────────────────────────
  if (sub === "approve") {
    if (!isAdmin(senderID))
      return api.sendMessage("⚠️ هذا الأمر للأدمن فقط.", threadID, messageID);

    const list = global.reportData.pendingCache;
    if (!list || list.length === 0)
      return api.sendMessage("⚠️ لا يوجد قائمة معلقة محمّلة. استخدم -report pending أولاً.", threadID, messageID);

    let approveList = [];
    const target = (args[1] || "").toLowerCase();

    if (target === "all") {
      approveList = list;
    } else {
      const idx = parseInt(target);
      if (isNaN(idx) || idx < 1 || idx > list.length)
        return api.sendMessage(`⚠️ رقم غير صحيح. أدخل رقماً بين 1 و ${list.length}.`, threadID, messageID);
      approveList = [list[idx - 1]];
    }

    let count = 0;
    let userInfo;
    try { userInfo = await api.getUserInfo(senderID); } catch (e) { userInfo = {}; }
    const approverName = userInfo[senderID]?.name || "Admin";

    for (const group of approveList) {
      try {
        await api.sendMessage(
          `✅ تمت الموافقة على المجموعة!\n━━━━━━━━━━━━━━━\n👑 وافق عليها: ${approverName}\n━━━━━━━━━━━━━━━\n🤖 الآن يمكنك استخدام جميع أوامر البوت.`,
          group.threadID
        );
        count++;
      } catch (e) {}
    }

    global.reportData.pendingCache = list.filter(g => !approveList.includes(g));
    return api.sendMessage(`✅ تم قبول ${count} مجموعة بنجاح.`, threadID, messageID);
  }

  // ─────────────────────────────────────────────
  // -report (بدون reply) — دليل الاستخدام
  // ─────────────────────────────────────────────
  if (!reply) {
    return api.sendMessage(
      `📌 دليل استخدام -report:\n${"═".repeat(28)}\n\n` +
      `🔴 للإبلاغ عن رسالة:\nرد على الرسالة المخالفة واكتب:\n-report\n\n` +
      `⚠️ نوع البلاغ: ${ABUSE_LABEL} (ثابت دائماً)\n` +
      `📊 الحد الأقصى للبلاغات: ${MAX_REPORTS} بلاغ لكل رسالة\n\n` +
      `${"─".repeat(28)}\n🔧 أوامر الأدمن:\n` +
      `  -report kick           — طرد صاحب الرسالة\n` +
      `  -report kick [uid]     — طرد بالمعرّف\n` +
      `  -report pending        — طلبات الانضمام المعلقة\n` +
      `  -report approve [رقم]  — قبول طلب\n` +
      `  -report approve all    — قبول الكل\n` +
      `  -report autokick on/off — طرد تلقائي\n` +
      `  -report set [عدد]      — ضبط حد البلاغات (1-${MAX_REPORTS})\n` +
      `  -report list           — عرض البلاغات\n` +
      `  -report clear          — مسح البلاغات\n\n` +
      `📊 الإعدادات الحالية:\n  الحد: ${global.reportData.threshold} بلاغ\n  الأقصى: ${MAX_REPORTS} بلاغ\n  طرد تلقائي: ${global.reportData.autoKick ? "مفعّل ✅" : "معطّل ❌"}`,
      threadID, messageID
    );
  }

  // ─────────────────────────────────────────────
  // -report — رد على رسالة (إساءة دائماً)
  // ─────────────────────────────────────────────
  const reportedMsgID = reply.messageID;
  const reportedUID   = String(reply.senderID);
  const reportedBody  = reply.body || "";

  if (reportedUID === senderID)
    return api.sendMessage("⚠️ لا يمكنك الإبلاغ عن رسائلك الخاصة.", threadID, messageID);
  if (isAdmin(reportedUID))
    return api.sendMessage("⚠️ لا يمكن الإبلاغ عن أدمن البوت.", threadID, messageID);
  if (reportedUID === botID)
    return api.sendMessage("⚠️ لا يمكن الإبلاغ عن البوت.", threadID, messageID);

  if (!global.reportData.reports.has(reportedMsgID)) {
    global.reportData.reports.set(reportedMsgID, {
      count: 0, reporters: new Set(), violations: [],
      messageBody: reportedBody, senderID: reportedUID, threadID
    });
  }

  const entry = global.reportData.reports.get(reportedMsgID);

  if (entry.reporters.has(senderID))
    return api.sendMessage("⚠️ لقد أبلغت عن هذه الرسالة مسبقاً.", threadID, messageID);

  if (entry.count >= MAX_REPORTS)
    return api.sendMessage(
      `⛔ وصلت هذه الرسالة للحد الأقصى من البلاغات (${MAX_REPORTS}).\nتم إشعار الأدمن مسبقاً.`,
      threadID, messageID
    );

  entry.reporters.add(senderID);
  entry.count++;
  entry.violations.push(ABUSE_LABEL);

  const remaining = global.reportData.threshold - entry.count;

  if (entry.count < global.reportData.threshold) {
    return api.sendMessage(
      `✅ تم استلام بلاغك.\n${ABUSE_LABEL}\n📊 البلاغات: ${entry.count}/${global.reportData.threshold}\n⏳ متبقي ${remaining} بلاغ للإشعار.\n📌 الحد الأقصى: ${MAX_REPORTS} بلاغ.`,
      threadID, messageID
    );
  }

  const threadInfo = await api.getThreadInfo(threadID).catch(() => null);
  const groupName  = threadInfo?.threadName || `مجموعة ${threadID}`;

  const notifMsg =
    `🚨 تنبيه بلاغ — تم الوصول للحد!\n${"═".repeat(28)}\n` +
    `📍 المجموعة: ${groupName}\n` +
    `🆔 معرّف المجموعة: ${threadID}\n` +
    `👤 المُبلَّغ عنه: ${reportedUID}\n` +
    `💬 الرسالة: "${(reportedBody || "(صورة/ملف)").slice(0, 150)}"\n` +
    `📊 عدد البلاغات: ${entry.count}/${global.reportData.threshold}\n` +
    `⚠️ نوع البلاغ: ${ABUSE_LABEL}\n` +
    `📌 الحد الأقصى: ${MAX_REPORTS} بلاغ\n` +
    (global.reportData.autoKick ? `\n⚡ الطرد التلقائي: تم تنفيذه.` : `\n📌 لطرد العضو: -report kick ${reportedUID}`);

  await notifyAdmins(notifMsg);

  if (global.reportData.autoKick) {
    const canKick = await isBotGroupAdmin();
    if (canKick) {
      try { await api.removeUserFromGroup(reportedUID, threadID); } catch (e) {}
      api.sendMessage(
        `🚨 تم الوصول لحد البلاغات (${entry.count})!\n${ABUSE_LABEL}\n⚡ تم طرد العضو تلقائياً وإشعار الأدمن.`,
        threadID
      );
    } else {
      api.sendMessage(
        `🚨 تم الوصول لحد البلاغات (${entry.count})!\n${ABUSE_LABEL}\n⚠️ تعذّر الطرد التلقائي — البوت ليس أدمناً هنا.\nتم إشعار الأدمن.`,
        threadID
      );
    }
  } else {
    api.sendMessage(
      `🚨 تم الوصول لحد البلاغات (${entry.count})!\n${ABUSE_LABEL}\nتم إشعار الأدمن.`,
      threadID
    );
  }

  if (entry.count >= MAX_REPORTS) {
    global.reportData.reports.delete(reportedMsgID);
  }
};
