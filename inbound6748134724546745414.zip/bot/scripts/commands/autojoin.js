module.exports.config = {
  name: "autojoin",
  version: "1.0.0",
  permission: 2,
  credits: "Maro X bot",
  description: "قبول القروبات الجديدة تلقائياً بدون تدخل يدوي",
  prefix: true,
  category: "admin",
  usages: "autojoin [on/off/status]",
  cooldowns: 5,
  dependencies: {}
};

const STORAGE_KEY = "autojoin_enabled";

function isEnabled() {
  if (!global.autojoinEnabled) global.autojoinEnabled = true;
  return global.autojoinEnabled;
}

async function acceptAllPending(api) {
  try {
    const other = await api.getThreadList(50, null, ["OTHER"]) || [];
    const pending = await api.getThreadList(50, null, ["PENDING"]) || [];
    const allThreads = [...other, ...pending].filter(t => t.isGroup);

    for (const thread of allThreads) {
      try {
        await api.sendMessage(
          `✅ تم تفعيل البوت تلقائياً في هذا القروب!\n\nاكتب ${global.config.PREFIX}help لرؤية الأوامر`,
          thread.threadID
        );
        await new Promise(r => setTimeout(r, 2000));
      } catch (e) {}
    }
    return allThreads.length;
  } catch (e) {
    return 0;
  }
}

module.exports.onLoad = function ({ api }) {
  global.autojoinEnabled = true;

  setInterval(async () => {
    if (!isEnabled()) return;
    await acceptAllPending(api);
  }, 2 * 60 * 1000);
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID } = event;
  const action = (args[0] || "status").toLowerCase();

  if (action === "on") {
    global.autojoinEnabled = true;
    return api.sendMessage(
      "✅ تم تفعيل القبول التلقائي للقروبات!\nالبوت سيقبل كل قروب جديد تلقائياً كل دقيقتين.",
      threadID, messageID
    );
  }

  if (action === "off") {
    global.autojoinEnabled = false;
    return api.sendMessage(
      "❌ تم إيقاف القبول التلقائي للقروبات.",
      threadID, messageID
    );
  }

  if (action === "now") {
    const count = await acceptAllPending(api);
    return api.sendMessage(
      count > 0
        ? `✅ تم قبول ${count} قروب جديد الآن!`
        : "لا توجد قروبات معلقة حالياً.",
      threadID, messageID
    );
  }

  const status = isEnabled() ? "✅ مفعّل" : "❌ موقوف";
  return api.sendMessage(
    `📊 حالة القبول التلقائي: ${status}\n\nالأوامر:\n• ${global.config.PREFIX}autojoin on — تفعيل\n• ${global.config.PREFIX}autojoin off — إيقاف\n• ${global.config.PREFIX}autojoin now — قبول فوري لكل القروبات المعلقة`,
    threadID, messageID
  );
};
