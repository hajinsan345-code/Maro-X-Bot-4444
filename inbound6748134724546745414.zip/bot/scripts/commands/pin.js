const axios = require("axios");
const fs = require("fs-extra");
const path = require("path");
const google = require("googlethis");

module.exports.config = {
  name: "pin",
  version: "1.2.0",
  permission: 0,
  credits: "IMRAN",
  premium: false,
  prefix: true,
  description: "search images from Pinterest",
  category: "with prefix",
  usages: "pin <query> | <count>",
  cooldowns: 10,
  dependencies: {
    "axios": "",
    "fs-extra": "",
    "googlethis": ""
  }
};

function upscalePinimg(url) {
  if (!/i\.pinimg\.com/.test(url)) return url;
  return url
    .replace(/\/(236x|474x|564x|736x|originals)\//, "/736x/");
}

async function searchPinterestImages(query, limit) {
  const results = await google.image(`${query} site:pinterest.com`, { safe: false });
  const urls = [];
  const seen = new Set();
  for (const r of results) {
    const u = r?.url;
    if (!u) continue;
    if (!/i\.pinimg\.com/.test(u)) continue;
    const big = upscalePinimg(u);
    if (seen.has(big)) continue;
    seen.add(big);
    urls.push(big);
    if (urls.length >= limit) break;
  }
  return urls;
}

module.exports.run = async ({ event, api, args }) => {
  let raw = (event.type === "message_reply" && event.messageReply?.body)
    ? event.messageReply.body
    : args.join(" ");

  if (!raw || !raw.trim()) {
    return api.sendMessage(
      "📌 Usage: pin <query> | <count>\nExample: pin anime girl | 6",
      event.threadID, event.messageID
    );
  }

  let [queryPart, countPart] = raw.split("|").map(s => s && s.trim());
  const query = queryPart;
  let limit = parseInt(countPart, 10);
  if (isNaN(limit) || limit < 1) limit = 6;
  if (limit > 12) limit = 12;

  api.sendMessage(`🔎 Searching Pinterest for "${query}"...`, event.threadID, event.messageID);

  let urls = [];
  try {
    urls = await searchPinterestImages(query, limit);
  } catch (e) {
    console.error("[pin] search error:", e.message);
    return api.sendMessage(
      `❌ Pinterest search failed: ${e.message}`,
      event.threadID, event.messageID
    );
  }

  if (!urls.length) {
    return api.sendMessage(
      `❌ No Pinterest images found for "${query}".`,
      event.threadID, event.messageID
    );
  }

  const cacheDir = path.join(__dirname, "cache");
  fs.ensureDirSync(cacheDir);

  const streams = [];
  let i = 0;
  for (const u of urls) {
    try {
      const ext = (u.match(/\.(jpe?g|png|gif|webp)/i) || [])[1] || "jpg";
      const file = path.join(cacheDir, `pin-${Date.now()}-${i}.${ext}`);
      const buf = await axios.get(u, {
        responseType: "arraybuffer",
        timeout: 20000,
        headers: {
          "User-Agent": "Mozilla/5.0",
          "Referer": "https://www.pinterest.com/"
        }
      });
      fs.writeFileSync(file, buf.data);
      streams.push(
        fs.createReadStream(file).on("end", () => {
          fs.unlink(file, () => {});
        })
      );
      i++;
    } catch (e) {
      console.error("[pin] download error:", e.message);
    }
  }

  if (!streams.length) {
    return api.sendMessage(
      "❌ Found results but could not download any image.",
      event.threadID, event.messageID
    );
  }

  return api.sendMessage(
    {
      body: `📌 Pinterest results for "${query}"\nShowing ${streams.length} image${streams.length > 1 ? "s" : ""}.`,
      attachment: streams
    },
    event.threadID, event.messageID
  );
};
