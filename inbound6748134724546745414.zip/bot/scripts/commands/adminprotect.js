const persist = require("../../main/system/utils/adminProtectPersist");

module.exports.config = {
  name: "adminprotect",
  version: "1.1.0",
  permission: 1,
  credits: "Maro X bot",
  description: "حماية قائمة المشرفين — من ينزع مسؤولاً يُنزع تلقائياً",
  prefix: true,
  premium: false,
  category: "admin",
  usages: "adminprotect [on/off/status]",
  cooldowns: 5,
  dependencies: {}
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID } = event;
  const botID = String(api.getCurrentUserID());

  persist.load();
  if (!global.adminProtectData) global.adminProtectData = new Map();

  const sub = (args[0] || "").toLowerCase();
  const protection = global.adminProtectData.get(threadID) || { enabled: false };

  if (sub === "on") {
    let threadInfo;
    try {
      threadInfo = await api.getThreadInfo(threadID);
    } catch (e) {
      return api.sendMessage("⚠️ تعذّر جلب معلومات المجموعة.", threadID, messageID);
    }

    const adminIDs = (threadInfo.adminIDs || []).map(a => String(a.id));

    if (!adminIDs.includes(botID)) {
      return api.sendMessage(
        "❌ البوت ليس مشرفاً في هذه المجموعة.\n" +
        "يجب تعيين البوت كمشرف أولاً لتفعيل الحماية.",
        threadID, messageID
      );
    }

    global.adminProtectData.set(threadID, { enabled: true });
    persist.save();

    return api.sendMessage(
      `🛡️ نظام حماية المشرفين\n` +
      `${"━".repeat(28)}\n\n` +
      `✅ تم تفعيل الحماية بنجاح!\n\n` +
      `📋 كيف يعمل النظام:\n` +
      `• أي شخص يحاول نزع صلاحية مشرف\n` +
      `  سيتم نزعه هو تلقائياً من الإدارة فوراً.\n\n` +
      `⚡ الحماية تعمل الآن في الخلفية.\n` +
      `${"━".repeat(28)}\n` +
      `للإيقاف: -adminprotect off`,
      threadID, messageID
    );
  }

  if (sub === "off") {
    global.adminProtectData.set(threadID, { enabled: false });
    persist.save();

    return api.sendMessage(
      `🛡️ نظام حماية المشرفين\n` +
      `${"━".repeat(28)}\n\n` +
      `⛔ تم إيقاف الحماية.\n\n` +
      `لإعادة التفعيل: -adminprotect on`,
      threadID, messageID
    );
  }

  if (sub === "status") {
    const isEnabled = protection.enabled;
    return api.sendMessage(
      `🛡️ نظام حماية المشرفين\n` +
      `${"━".repeat(28)}\n\n` +
      `الحالة: ${isEnabled ? "✅ مفعّل" : "❌ معطّل"}\n\n` +
      `${isEnabled
        ? "أي محاولة لنزع مشرف ستُقابل بنزع المعتدي تلقائياً."
        : "الحماية متوقفة، استخدم -adminprotect on لتفعيلها."
      }`,
      threadID, messageID
    );
  }

  return api.sendMessage(
    `🛡️ نظام حماية المشرفين\n` +
    `${"━".repeat(28)}\n\n` +
    `الاستخدام:\n` +
    `-adminprotect on      — تفعيل الحماية\n` +
    `-adminprotect off     — إيقاف الحماية\n` +
    `-adminprotect status  — حالة الحماية\n\n` +
    `📋 الوصف:\n` +
    `إذا حاول أي مشرف نزع صلاحية مشرف آخر،\n` +
    `سيتم نزعه هو تلقائياً من الإدارة فوراً.`,
    threadID, messageID
  );
};
