module.exports.config = {
  name: "help",
  version: "5.0.0",
  permission: 0,
  credits: "Maro X bot",
  description: "قائمة الأوامر الرسمية للنظام",
  prefix: true,
  premium: false,
  category: "guide",
  usages: "[الصفحة]",
  cooldowns: 5,
};

const HELP_GIF_URL =
  "https://i.postimg.cc/8kfQ4WTj/14a6051f40d98f3a41ad5955d59146f5.gif";

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID } = event;
  const axios = require("axios");
  const fs = require("fs-extra");
  const { commands } = global.client;

  const listCommand = Array.from(commands.values());
  let page = parseInt(args[0]) || 1;
  const limit = 6; // عدد الأقسام في كل صفحة
  const totalPages = Math.ceil(listCommand.length / limit);
  if (page < 1 || page > totalPages) page = 1;

  // --- التنسيق الرسمي الجديد (Minimalist Professional) ---
  let helpText = `『 𝗠𝗔𝗥𝗢 𝗫 𝗠𝗘𝗡𝗨 』\n`;
  helpText += `📑 𝖯𝖺𝗀𝖾: ${page} 𝗈𝖿 ${totalPages}\n`;
  helpText += `╼╼╼╼╼╼╼╼╼╼╼╼╼╼\n\n`;

  const start = (page - 1) * limit;
  const cmdsPage = listCommand.slice(start, start + limit);

  cmdsPage.forEach((cmd, index) => {
    const num = start + index + 1;
    // اسم القسم أو الأمر بخط عريض وأنيق
    helpText += `${num} ─ 𝗦𝘆𝘀𝘁𝗲𝗺.${cmd.config.name.toUpperCase()}:\n`;
    // وصف الوظيفة
    helpText += `┊ ${cmd.config.description || "لا يوجد وصف متوفر حالياً."} ◈\n`;
    // الأوامر المتاحة
    helpText += `╰ 𝖢𝗈𝗆𝗆𝖺𝗇𝖽𝗌: [ ${cmd.config.name} ]\n\n`;
  });

  helpText += `╼╼╼╼╼╼╼╼╼╼╼╼╼╼\n`;
  helpText += `💡 𝖳𝗒𝗉𝖾 [ help 2 ] 𝖿𝗈𝗋 𝗇𝖾𝗑𝗍 𝗉𝖺𝗀𝖾\n`;
  helpText += `📊 𝖲𝗍𝖺𝗍𝗎𝗌: 𝖮𝗉𝖾𝗋𝖺𝗍𝗂𝗈𝗇𝖺𝗅`;

  try {
    return api.sendMessage(
      helpText,
      threadID,
      async (err, info) => {
        if (err) return console.error(err);

        try {
          const path = __dirname + `/cache/maro_pro_${Date.now()}.gif`;
          const response = await axios.get(HELP_GIF_URL, {
            responseType: "arraybuffer",
          });
          fs.writeFileSync(
            path,
            Buffer.from(response.data, "binary"),
            "binary",
          );

          return api.sendMessage(
            {
              attachment: fs.createReadStream(path),
            },
            threadID,
            () => {
              if (fs.existsSync(path)) fs.unlinkSync(path);
            },
          );
        } catch (e) {
          console.error("GIF Error:", e);
        }
      },
      messageID,
    );
  } catch (error) {
    return api.sendMessage("⚠️ System error occurred.", threadID, messageID);
  }
};
