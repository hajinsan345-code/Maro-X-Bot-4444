const moment = require("moment-timezone");

module.exports.config = {
  name: "autotime",
  version: "1.0.0",
  permission: 0,
  credits: "Maro X bot",
  description: "Automatic time-based messages",
  prefix: true,
  category: "user",
  usages: "",
  cooldowns: 5,
  dependencies: {
    "moment-timezone": ""
  }
};

module.exports.onLoad = function () {};

module.exports.run = function () {};
