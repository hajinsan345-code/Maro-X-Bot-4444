module.exports.config = {
        name: "uns",
        version: "1.0.5",
        permission: 0,
        credits: "Maro X bot",
        prefix: true,
        description: "message unsend",
        category: "admin",
        usages: " ",
        cooldowns: 5
};


module.exports.languages = {
        "vi": {
                "returnCant": "Không thể gỡ tin nhắn của người khác.",
                "missingReply": "Hãy reply tin nhắn cần gỡ."
        },
        "en": {
                "returnCant": "Can't to unsend message from other user.",
                "missingReply": "Reply to the message you want to unsend."
        }
}

module.exports.run = function({ api, event, getText }) {
        if (event.type != "message_reply") return api.sendMessage(getText("missingReply"), event.threadID, event.messageID);
        if (event.messageReply.senderID != api.getCurrentUserID()) return api.sendMessage(getText("returnCant"), event.threadID, event.messageID);
        return api.unsendMessage(event.messageReply.messageID);
}
