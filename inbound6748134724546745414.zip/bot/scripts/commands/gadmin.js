module.exports.config = {
  name: "gadmin",
  version: "1.2.0",
  permission: 1,
  credits: "Maro X bot",
  description: "إدارة مسؤولي المجموعة — إضافة أو نزع صلاحيات الادمن",
  prefix: true,
  premium: false,
  category: "Group",
  usages: "gadmin [add/remove/removeall/list] [@mention / اسم / UID]",
  cooldowns: 5,
};

// ─── بحث عن أقرب اسم بين أعضاء المجموعة ─────────────────────────────────────
async function findMemberByName(api, participantIDs, query) {
  const q = query.replace(/@/g, "").trim().toLowerCase();
  if (!q) return null;

  // جلب معلومات جميع الأعضاء دفعةً واحدة
  let allInfo = {};
  try {
    // getUserInfo يقبل مصفوفة من IDs
    allInfo = await api.getUserInfo(participantIDs);
  } catch (_) {
    // fallback: جلب واحداً واحداً
    for (const id of participantIDs) {
      try {
        const info = await api.getUserInfo(id);
        Object.assign(allInfo, info);
      } catch (_) {}
    }
  }

  let best = null;
  let bestScore = 0;

  for (const [id, data] of Object.entries(allInfo)) {
    const name = (data.name || "").toLowerCase();
    if (!name) continue;

    // تطابق تام
    if (name === q) return { id, name: data.name };

    // تطابق جزئي
    if (name.includes(q) || q.includes(name)) {
      const score = Math.min(name.length, q.length) / Math.max(name.length, q.length);
      if (score > bestScore) {
        bestScore = score;
        best = { id, name: data.name };
      }
    }
  }

  // قبول إذا كان التطابق معقول (أكثر من 40%)
  return bestScore >= 0.4 ? best : null;
}

module.exports.run = async function ({ api, event, args }) {

  const threadID  = String(event.threadID);
  const messageID = event.messageID;
  const senderID  = String(event.senderID);
  const mentions  = event.mentions || {};

  const lang = global.config.language === "ar" ? "ar" : "en";

  const T = {
    en: {
      notGroup:     "⛔ This command only works inside a group.",
      botNotAdmin:  "⛔ The bot is not a group admin and cannot change admin status.",
      noPermission: "⛔ Only group admins or bot admins can use this command.",
      usage:        "📌 Usage:\n  -gadmin add @mention / name / UID\n  -gadmin remove @mention / name / UID\n  -gadmin removeall\n  -gadmin list",
      noTarget:     "⚠️ Please mention a user, write their name, or provide a UID.",
      notFound:     (n) => `⚠️ Could not find any member named "${n}" in this group.`,
      notInGroup:   (n) => `⚠️ ${n} is not in this group.`,
      alreadyAdmin: (n) => `ℹ️ ${n} is already an admin.`,
      notAdmin:     (n) => `ℹ️ ${n} is not an admin.`,
      addedOne:     (n) => `✅ Successfully promoted ${n} to group admin.`,
      addedMany:    (c, l) => `✅ Promoted ${c} member(s) to group admin:\n${l}`,
      removedOne:   (n) => `✅ Removed admin role from ${n}.`,
      removedMany:  (c, l) => `✅ Removed admin role from ${c} member(s):\n${l}`,
      removedAll:   (c, l) => `✅ Removed admin role from all ${c} admin(s):\n${l}`,
      noAdminsLeft: "ℹ️ No admins to remove (other than the bot).",
      listTitle:    (c) => `👥 Group admins (${c}):`,
      noAdmins:     "ℹ️ This group has no admins.",
      errUser:      (n, e) => `❌ Error for ${n}: ${e}`,
      botSelf:      "🤖 Cannot remove the bot's own admin role.",
      foundByName:  (n, id) => `🔍 Found by name: ${n} (${id})`,
    },
    ar: {
      notGroup:     "⛔ هذا الأمر يعمل فقط داخل المجموعات.",
      botNotAdmin:  "⛔ البوت ليس مسؤولاً في هذه المجموعة ولا يستطيع تغيير الصلاحيات.",
      noPermission: "⛔ فقط مسؤولو المجموعة أو البوت يمكنهم استخدام هذا الأمر.",
      usage:        "📌 طريقة الاستخدام:\n  -gadmin add @تاغ / اسم / UID\n  -gadmin remove @تاغ / اسم / UID\n  -gadmin removeall\n  -gadmin list",
      noTarget:     "⚠️ يرجى تاغ شخص أو كتابة اسمه أو UID الخاص به.",
      notFound:     (n) => `⚠️ لم يتم العثور على عضو باسم "${n}" في هذه المجموعة.`,
      notInGroup:   (n) => `⚠️ ${n} ليس في هذه المجموعة.`,
      alreadyAdmin: (n) => `ℹ️ ${n} هو مسؤول بالفعل.`,
      notAdmin:     (n) => `ℹ️ ${n} ليس مسؤولاً.`,
      addedOne:     (n) => `✅ تم ترقية ${n} إلى مسؤول المجموعة.`,
      addedMany:    (c, l) => `✅ تم ترقية ${c} عضو إلى مسؤول:\n${l}`,
      removedOne:   (n) => `✅ تم نزع صلاحية المسؤول من ${n}.`,
      removedMany:  (c, l) => `✅ تم نزع صلاحية المسؤول من ${c} شخص:\n${l}`,
      removedAll:   (c, l) => `✅ تم نزع صلاحية الكل (${c}) مسؤول:\n${l}`,
      noAdminsLeft: "ℹ️ لا يوجد مسؤولون لنزع صلاحياتهم.",
      listTitle:    (c) => `👥 مسؤولو المجموعة (${c}):`,
      noAdmins:     "ℹ️ لا يوجد مسؤولون في هذه المجموعة.",
      errUser:      (n, e) => `❌ خطأ مع ${n}: ${e}`,
      botSelf:      "🤖 لا يمكن نزع صلاحية البوت من نفسه.",
      foundByName:  (n, id) => `🔍 تم العثور بالاسم: ${n} (${id})`,
    }
  }[lang];

  // ─── جلب معلومات المجموعة ──────────────────────────────────────────────
  let threadInfo;
  try {
    threadInfo = await api.getThreadInfo(threadID);
  } catch (e) {
    return api.sendMessage("❌ فشل جلب معلومات المجموعة: " + e.message, threadID, messageID);
  }

  if (!threadInfo.isGroup) {
    return api.sendMessage(T.notGroup, threadID, messageID);
  }

  const rawAdminIDs    = (threadInfo.adminIDs    || []).map(a => String(a.id));
  const rawParticipants = (threadInfo.participantIDs || []).map(String);
  const botID          = String(api.getCurrentUserID());

  const { ADMINBOT = [], OWNER = [], OPERATOR = [] } = global.config;
  const isBotAdmin   = ADMINBOT.includes(senderID) || OWNER.includes(senderID) || OPERATOR.includes(senderID);
  const isGroupAdmin = rawAdminIDs.includes(senderID);

  if (!isBotAdmin && !isGroupAdmin) {
    return api.sendMessage(T.noPermission, threadID, messageID);
  }

  if (!rawAdminIDs.includes(botID)) {
    return api.sendMessage(T.botNotAdmin, threadID, messageID);
  }

  const sub = (args[0] || "").toLowerCase();

  // ─── دالة مساعدة: استخراج كل الأرقام (UIDs) من نص الرسالة ───────────────
  function extractUIDsFromBody(body) {
    // فيسبوك يُرسل المنشن أحياناً كـ @100001234567890 أو ‎@100001234567890
    const matches = (body || "").match(/(?:^|\s|‎)@?(\d{8,18})(?:\s|$|@)/g) || [];
    return matches.map(m => m.replace(/[^0-9]/g, "")).filter(Boolean);
  }

  // ─── دالة مساعدة: بناء قائمة الأهداف من mentions أو UID أو اسم ──────────
  async function resolveTargets() {
    const mentionIDs = Object.keys(mentions);

    // ── الأولوية 1: منشن حقيقي من فيسبوك ──────────────────────────────────
    if (mentionIDs.length > 0) {
      const targets = mentionIDs.map(id => ({
        id: String(id),
        name: String(mentions[id]).replace(/@/g, "").trim() || String(id),
      }));
      // تحقق أن الأسماء ليست فارغة، وإلا جلب الأسماء من API
      for (const t of targets) {
        if (!t.name || t.name === t.id) {
          try {
            const inf = await api.getUserInfo(t.id);
            t.name = inf[t.id]?.name || t.id;
          } catch (_) {}
        }
      }
      return targets;
    }

    // ── الأولوية 2: UID رقمي مباشر في args (بـ @ أو بدونه) ────────────────
    const allArgUIDs = [];
    for (let i = 1; i < args.length; i++) {
      const cleaned = args[i].replace(/^@/, "");
      if (/^\d{8,18}$/.test(cleaned)) {
        allArgUIDs.push(cleaned);
      }
    }
    if (allArgUIDs.length > 0) {
      const targets = [];
      for (const uid of allArgUIDs) {
        let name = uid;
        try { const inf = await api.getUserInfo(uid); name = inf[uid]?.name || uid; } catch (_) {}
        targets.push({ id: uid, name });
      }
      return targets;
    }

    // ── الأولوية 3: UIDs مستخرجة من نص الرسالة (fallback) ─────────────────
    const bodyUIDs = extractUIDsFromBody(event.body)
      .filter(uid => rawParticipants.includes(uid));
    if (bodyUIDs.length > 0) {
      const targets = [];
      for (const uid of bodyUIDs) {
        let name = uid;
        try { const inf = await api.getUserInfo(uid); name = inf[uid]?.name || uid; } catch (_) {}
        targets.push({ id: uid, name });
      }
      return targets;
    }

    // ── الأولوية 4: بحث بالاسم — كل ما بعد args[1] هو الاسم ──────────────
    if (args[1]) {
      const nameQuery = args.slice(1).join(" ").replace(/@/g, "").trim();
      if (!nameQuery) return [];

      const found = await findMemberByName(api, rawParticipants, nameQuery);
      if (!found) return [{ id: null, name: nameQuery, notFound: true }];
      return [found];
    }

    return [];
  }

  // ─────────────────────────────────────────────────────────────────────────
  // list
  // ─────────────────────────────────────────────────────────────────────────
  if (sub === "list" || sub === "ls" || sub === "-l") {
    if (rawAdminIDs.length === 0) {
      return api.sendMessage(T.noAdmins, threadID, messageID);
    }
    const lines = [];
    for (let i = 0; i < rawAdminIDs.length; i++) {
      const id = rawAdminIDs[i];
      let name = id;
      try { const inf = await api.getUserInfo(id); name = inf[id]?.name || id; } catch (_) {}
      lines.push(`${i + 1}. ${name}${id === botID ? " 🤖" : ""}\n   ID: ${id}`);
    }
    return api.sendMessage(T.listTitle(rawAdminIDs.length) + "\n\n" + lines.join("\n\n"), threadID, messageID);
  }

  // ─────────────────────────────────────────────────────────────────────────
  // add
  // ─────────────────────────────────────────────────────────────────────────
  if (sub === "add" || sub === "+" || sub === "promote") {
    const targets = await resolveTargets();

    if (targets.length === 0) {
      // ── DEBUG TEMPORARY ──
      const dbg = [
        "🔍 [gadmin debug] no targets found",
        `args: ${JSON.stringify(args)}`,
        `mentions: ${JSON.stringify(event.mentions || {})}`,
        `body: ${event.body}`,
      ].join("\n");
      return api.sendMessage(dbg, threadID, messageID);
    }

    const added   = [];
    const skipped = [];

    for (const t of targets) {
      // لم يُعثر عليه بالاسم
      if (t.notFound) {
        skipped.push(T.notFound(t.name));
        continue;
      }
      if (!rawParticipants.includes(t.id)) {
        skipped.push(T.notInGroup(t.name));
        continue;
      }
      if (rawAdminIDs.includes(t.id)) {
        skipped.push(T.alreadyAdmin(t.name));
        continue;
      }
      try {
        await api.changeAdminStatus(threadID, [t.id], true);
        added.push(`• ${t.name} (${t.id})`);
        rawAdminIDs.push(t.id);
      } catch (e) {
        skipped.push(T.errUser(t.name, e.error || e.message || String(e)));
      }
    }

    const parts = [];
    if (added.length === 1) {
      const n = targets.find(t => `• ${t.name} (${t.id})` === added[0])?.name || added[0];
      parts.push(T.addedOne(n));
    } else if (added.length > 1) {
      parts.push(T.addedMany(added.length, added.join("\n")));
    }
    if (skipped.length > 0) parts.push(skipped.join("\n"));

    return api.sendMessage(parts.join("\n\n") || T.noTarget, threadID, messageID);
  }

  // ─────────────────────────────────────────────────────────────────────────
  // remove
  // ─────────────────────────────────────────────────────────────────────────
  if (sub === "remove" || sub === "rm" || sub === "-" || sub === "demote") {
    const targets = await resolveTargets();

    if (targets.length === 0) {
      return api.sendMessage(T.noTarget, threadID, messageID);
    }

    const removed = [];
    const skipped = [];

    for (const t of targets) {
      if (t.notFound) {
        skipped.push(T.notFound(t.name));
        continue;
      }
      if (t.id === botID) {
        skipped.push(T.botSelf);
        continue;
      }
      if (!rawAdminIDs.includes(t.id)) {
        skipped.push(T.notAdmin(t.name));
        continue;
      }
      try {
        await api.changeAdminStatus(threadID, [t.id], false);
        removed.push(`• ${t.name} (${t.id})`);
        rawAdminIDs.splice(rawAdminIDs.indexOf(t.id), 1);
      } catch (e) {
        skipped.push(T.errUser(t.name, e.error || e.message || String(e)));
      }
    }

    const parts = [];
    if (removed.length === 1) {
      const n = targets.find(t => `• ${t.name} (${t.id})` === removed[0])?.name || removed[0];
      parts.push(T.removedOne(n));
    } else if (removed.length > 1) {
      parts.push(T.removedMany(removed.length, removed.join("\n")));
    }
    if (skipped.length > 0) parts.push(skipped.join("\n"));

    return api.sendMessage(parts.join("\n\n") || T.noTarget, threadID, messageID);
  }

  // ─────────────────────────────────────────────────────────────────────────
  // removeall  (فقط ادمن البوت)
  // ─────────────────────────────────────────────────────────────────────────
  if (sub === "removeall" || sub === "rmall" || sub === "clearadmins") {
    if (!isBotAdmin) {
      return api.sendMessage(T.noPermission, threadID, messageID);
    }

    const targets = rawAdminIDs.filter(id => id !== botID);
    if (targets.length === 0) {
      return api.sendMessage(T.noAdminsLeft, threadID, messageID);
    }

    // جلب الأسماء
    let allInfo = {};
    try { allInfo = await api.getUserInfo(targets); } catch (_) {}

    const removed = [];
    const skipped = [];

    for (const id of targets) {
      const name = allInfo[id]?.name || id;
      try {
        await api.changeAdminStatus(threadID, [id], false);
        removed.push(`• ${name} (${id})`);
      } catch (e) {
        skipped.push(T.errUser(name, e.error || e.message || String(e)));
      }
    }

    const parts = [];
    if (removed.length > 0) parts.push(T.removedAll(removed.length, removed.join("\n")));
    if (skipped.length > 0) parts.push(skipped.join("\n"));

    return api.sendMessage(parts.join("\n\n") || T.noAdminsLeft, threadID, messageID);
  }

  // ─── افتراضي ─────────────────────────────────────────────────────────────
  return api.sendMessage(T.usage, threadID, messageID);
};
