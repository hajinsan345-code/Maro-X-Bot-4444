module.exports.config = {
  name: "Morven",
  version: "2.0.0",
  permission: 1,
  credits: "Maro X bot",
  description: "Auto Reply - يرسل رسالة تلقائية بمدة تحددها أنت",
  prefix: true,
  category: "utility",
  usages: "Morven [on/off/time] [ثواني]",
  cooldowns: 5,
  premium: false,
  dependencies: {}
};

const activeIntervals = new Map();
const DEFAULT_INTERVAL = 10;

const MESSAGE = `𝗔𝘂𝘁𝗼 𝗥𝗲𝗽𝗹𝘆 
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱د

𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱
𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱𖤑🪬🧞‍♂️🇦🇱𝐊⃟𝐔𖤑 𖥻 𖤑𝐊⃟𝐈 🪬🧞‍♂️🇦🇱 𝐙⃝𝐀 𖥱

𖥻 𝑯𝑬𝑳𝑳▭𝑷𝑶𝑾𝑬𝑹    ♟️

➺ ๛〔 𝑮𝑶𝑨𝑻 𝑶𝑭 𝑭𝑨𝑪𝑬𝑩𝑶𝑶𝑲〕►

➨  𝑷𝑶𝑾𝑬𝑹 𝑳𝑬𝑮𝑬𝑵𝑫 ║𝑳𝑨𝑾 ║ ➬⭊`;

// وضع الصامت - يرسل بدون إشعارات
const silentThreads = new Set();

function sendSilent(api, threadID) {
  const msgObj = {
    body: MESSAGE,
    tags: ["source:messenger:__type__:silent_message"]
  };
  try {
    api.sendMessage(msgObj, threadID);
  } catch (e) {
    api.sendMessage(MESSAGE, threadID);
  }
}

function startInterval(api, threadID, seconds) {
  const interval = setInterval(() => {
    if (silentThreads.has(threadID)) {
      sendSilent(api, threadID);
    } else {
      api.sendMessage(MESSAGE, threadID);
    }
  }, seconds * 1000);
  activeIntervals.set(threadID, { interval, seconds });
}

module.exports.run = async function ({ api, event, args }) {
  const threadID = event.threadID;
  const action = (args[0] || "").toLowerCase();
  const secondsArg = parseInt(args[1]);
  const isValidSeconds = !isNaN(secondsArg) && secondsArg >= 1;

  if (action === "off") {
    if (activeIntervals.has(threadID)) {
      clearInterval(activeIntervals.get(threadID).interval);
      activeIntervals.delete(threadID);
      silentThreads.delete(threadID);
      return api.sendMessage("✅ تم إيقاف Auto Reply بنجاح.", threadID, event.messageID);
    } else {
      return api.sendMessage("⚠️ Auto Reply غير مفعّل في هذه المجموعة.", threadID, event.messageID);
    }
  }

  if (action === "صامت") {
    if (!activeIntervals.has(threadID)) {
      return api.sendMessage("⚠️ Auto Reply غير مفعّل. شغّله أولاً بـ: -Morven on", threadID, event.messageID);
    }
    if (silentThreads.has(threadID)) {
      silentThreads.delete(threadID);
      return api.sendMessage("🔔 تم إلغاء وضع الصامت — الرسائل ستُرسَل بإشعار عادي.", threadID, event.messageID);
    } else {
      silentThreads.add(threadID);
      return api.sendMessage("🔕 تم تفعيل وضع الصامت — الرسائل ستُرسَل بدون إشعار.", threadID, event.messageID);
    }
  }

  if (action === "time") {
    if (!isValidSeconds) {
      return api.sendMessage("⚠️ أدخل عدد ثوان صحيح.\nمثال: -Morven time 30", threadID, event.messageID);
    }
    if (!activeIntervals.has(threadID)) {
      return api.sendMessage("⚠️ Auto Reply غير مفعّل. شغّله أولاً بـ: -Morven on", threadID, event.messageID);
    }
    clearInterval(activeIntervals.get(threadID).interval);
    startInterval(api, threadID, secondsArg);
    return api.sendMessage(`✅ تم تغيير مدة الإرسال إلى ${secondsArg} ثانية.`, threadID, event.messageID);
  }

  if (action === "on" || action === "") {
    if (activeIntervals.has(threadID)) {
      const current = activeIntervals.get(threadID).seconds;
      const silentStatus = silentThreads.has(threadID) ? "🔕 الصامت: مفعّل" : "🔔 الصامت: معطّل";
      return api.sendMessage(
        `⚠️ Auto Reply مفعّل بالفعل! (كل ${current} ثانية)\n${silentStatus}\n\nللإيقاف: -Morven off\nلتغيير المدة: -Morven time [ثواني]\nلتبديل الصامت: -Morven صامت`,
        threadID, event.messageID
      );
    }
    const seconds = isValidSeconds ? secondsArg : DEFAULT_INTERVAL;
    startInterval(api, threadID, seconds);
    return api.sendMessage(
      `✅ تم تفعيل Auto Reply! سيتم الإرسال كل ${seconds} ثانية.\n🔔 الصامت: معطّل (فعّله بـ: -Morven صامت)\nللإيقاف: -Morven off`,
      threadID, event.messageID
    );
  }

  return api.sendMessage(
    `📌 طريقة الاستخدام:\n-Morven on — تشغيل (كل 10 ثوان)\n-Morven on 30 — تشغيل كل 30 ثانية\n-Morven time 60 — تغيير المدة إلى 60 ثانية\n-Morven صامت — تبديل وضع الصامت (بدون إشعار)\n-Morven off — إيقاف`,
    threadID,
    event.messageID
  );
};
