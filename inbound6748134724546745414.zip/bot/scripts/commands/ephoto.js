const fs = require("fs");
const path = require("path");
const axios = require("axios");

module.exports.config = {
  name: "ephoto",
  version: "2.0.0",
  permission: 0,
  credits: "Maro X bot",
  description: "Generate stylish text effect images using Ephoto360",
  prefix: true,
  premium: false,
  category: "textmaker",
  usages: "ephoto <template 1-25> <your text>",
  cooldowns: 8
};

const templates = {
  "1":  "https://en.ephoto360.com/handwritten-text-on-foggy-glass-online-680.html",
  "2":  "https://en.ephoto360.com/create-realistic-cloud-text-effect-606.html",
  "3":  "https://en.ephoto360.com/light-glow-text-effect-369.html",
  "4":  "https://en.ephoto360.com/glitch-text-effect-online-345.html",
  "5":  "https://en.ephoto360.com/3d-metal-text-effect-600.html",
  "6":  "https://en.ephoto360.com/foggy-rainy-text-effect-75.html",
  "7":  "https://en.ephoto360.com/write-in-sand-summer-beach-online-free-595.html",
  "8":  "https://en.ephoto360.com/diamond-text-95.html",
  "9":  "https://en.ephoto360.com/create-multicolored-neon-light-signatures-591.html",
  "10": "https://en.ephoto360.com/create-broken-glass-text-effect-online-698.html",
  "11": "https://en.ephoto360.com/create-multicolored-signature-attachment-arrow-effect-714.html",
  "12": "https://en.ephoto360.com/create-a-graffiti-text-effect-on-the-wall-online-665.html",
  "13": "https://en.ephoto360.com/create-a-watercolor-text-effect-online-655.html",
  "14": "https://en.ephoto360.com/creating-text-effects-night-lend-for-word-effect-147.htm",
  "15": "https://en.ephoto360.com/write-text-effect-clouds-in-the-sky-online-619.html",
  "16": "https://en.ephoto360.com/write-in-sand-summer-beach-online-576.html",
  "17": "https://en.ephoto360.com/dark-green-typography-online-359.html",
  "18": "https://en.ephoto360.com/stars-night-online-1-85.html",
  "19": "https://en.ephoto360.com/realistic-3d-sand-text-effect-online-580.html",
  "20": "https://en.ephoto360.com/create-a-summery-sand-writing-text-effect-577.html",
  "21": "https://en.ephoto360.com/text-firework-effect-356.html",
  "22": "https://en.ephoto360.com/ligatures-effects-from-leaves-146.html",
  "23": "https://en.ephoto360.com/write-letters-on-the-leaves-248.html",
  "24": "https://en.ephoto360.com/graffiti-color-199.html",
  "25": "https://en.ephoto360.com/caper-cut-effect-184.html"
};

async function generateEphoto(templateUrl, text) {
  const client = axios.create({
    headers: {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
      "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
      "Accept-Language": "en-US,en;q=0.5",
      "Referer": "https://en.ephoto360.com/"
    },
    timeout: 20000
  });

  // Step 1: Fetch the page to get form token
  const pageResp = await client.get(templateUrl);
  const html = pageResp.data;

  // Extract token
  const tokenMatch = html.match(/name="_token"\s+value="([^"]+)"/);
  const token = tokenMatch ? tokenMatch[1] : "";

  // Extract slug from URL
  const slugMatch = templateUrl.match(/\/([^/]+)\.html?/);
  const slug = slugMatch ? slugMatch[1] : "";

  // Extract form action
  const actionMatch = html.match(/<form[^>]+action="([^"]+)"/);
  const action = actionMatch ? actionMatch[1] : `https://en.ephoto360.com/effect/${slug}`;

  // Extract all input fields
  const inputMatches = [...html.matchAll(/<input[^>]+name="([^"]+)"[^>]*value="([^"]*)"[^>]*>/g)];
  const formData = new URLSearchParams();
  for (const [, name, value] of inputMatches) {
    if (name !== "_token") formData.append(name, value);
  }
  formData.set("_token", token);

  // Find the text field name (usually "text", "name", "message", or "text_1")
  const textFieldMatch = html.match(/name="(text[\w]*|text_\d+|message|names?)"[^>]*type="text"/i) ||
                          html.match(/type="text"[^>]*name="(text[\w]*|text_\d+|message|names?)"/i);
  const textField = textFieldMatch ? textFieldMatch[1] : "text";
  formData.set(textField, text);

  // Step 2: Submit the form
  const submitResp = await client.post(action, formData.toString(), {
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      "Referer": templateUrl,
      "Origin": "https://en.ephoto360.com"
    }
  });

  const resultHtml = submitResp.data;

  // Extract output image URL
  const imgMatch = resultHtml.match(/output[^"]*\.(?:jpg|png|jpeg|gif|webp)/i) ||
                    resultHtml.match(/https:\/\/en\.ephoto360\.com\/[^"']*\.(jpg|png|jpeg|gif|webp)/i) ||
                    resultHtml.match(/src="([^"]*output[^"]*\.(jpg|png|jpeg|gif|webp))"/i);

  if (!imgMatch) throw new Error("Could not find output image in response");

  let imageUrl = imgMatch[0];
  if (!imageUrl.startsWith("http")) imageUrl = "https://en.ephoto360.com/" + imageUrl.replace(/^\//, "");

  return imageUrl;
}

module.exports.run = async ({ api, event, args }) => {
  if (args.length < 2) {
    const list = Object.keys(templates).map(k => `[${k}]`).join(" ");
    return api.sendMessage(
      `📸 Ephoto360 Text Effects\n\nUsage: -ephoto <number> <your text>\n\nAvailable templates:\n${list}\n\nExample:\n-ephoto 3 Maro\n-ephoto 9 Hello World`,
      event.threadID,
      event.messageID
    );
  }

  const key = args[0];
  const text = args.slice(1).join(" ");

  if (!templates[key]) {
    return api.sendMessage(
      `❌ Invalid template! Choose a number from 1 to 25.\nExample: -ephoto 5 Maro`,
      event.threadID,
      event.messageID
    );
  }

  if (text.length > 50) {
    return api.sendMessage(
      "❌ Text is too long! Maximum 50 characters.",
      event.threadID,
      event.messageID
    );
  }

  const cacheDir = path.join(__dirname, "cache");
  if (!fs.existsSync(cacheDir)) fs.mkdirSync(cacheDir, { recursive: true });
  const imagePath = path.join(cacheDir, `ephoto_${event.senderID}.png`);

  const waitMsg = await new Promise(resolve =>
    api.sendMessage(`⏳ Generating image for "${text}" using template #${key}...`, event.threadID, resolve, event.messageID)
  );

  try {
    const imageUrl = await generateEphoto(templates[key], text);

    const imgResp = await axios.get(imageUrl, {
      responseType: "arraybuffer",
      headers: { "Referer": "https://en.ephoto360.com/" },
      timeout: 20000
    });

    fs.writeFileSync(imagePath, Buffer.from(imgResp.data));

    try { api.unsendMessage(waitMsg.messageID); } catch (_) {}

    api.sendMessage(
      {
        body: `✅ Template #${key} | Text: "${text}"`,
        attachment: fs.createReadStream(imagePath)
      },
      event.threadID,
      () => { try { fs.unlinkSync(imagePath); } catch (_) {} },
      event.messageID
    );

  } catch (err) {
    try { api.unsendMessage(waitMsg.messageID); } catch (_) {}
    console.error("Ephoto error:", err.message);
    api.sendMessage(
      `❌ Failed to generate image. The template may be temporarily unavailable.\nTry another template (1-25).`,
      event.threadID,
      event.messageID
    );
  }
};
