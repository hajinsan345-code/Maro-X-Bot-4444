module.exports.config = {
  name: "cooling",
  version: "1.0.0",
  permission: 2,
  credits: "IMRAN",
  premium: false,
  prefix: true,
  description: "view bot cooling/throttling stats",
  category: "admin",
  usages: "cooling",
  cooldowns: 5,
  dependencies: {}
};

function fmtUptime(s) {
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return `${h}h ${m}m ${sec}s`;
}

module.exports.run = async ({ event, api }) => {
  const cooling = require('../../main/system/cooling');
  const s = cooling.getStats();
  const allowedTotal = s.total - s.throttled;
  const throttlePct = s.total > 0 ? ((s.throttled / s.total) * 100).toFixed(1) : '0';
  const memBar = (() => {
    const pct = Math.min(100, Math.round((s.memoryMB / s.limits.memoryHardMB) * 100));
    const filled = Math.round(pct / 5);
    return '█'.repeat(filled) + '░'.repeat(20 - filled) + ` ${pct}%`;
  })();

  const msg =
`❄️ نظام التبريد - حالة البوت

📊 الإحصائيات
├ إجمالي الطلبات    : ${s.total}
├ المسموح بها       : ${allowedTotal}
├ المُبرَّدة         : ${s.throttled} (${throttlePct}%)
├ رفض ذاكرة         : ${s.memoryRejects}
├ رفض تزامن         : ${s.concurrencyRejects}
└ آخر سبب           : ${s.lastReason || '—'}

⚙️ الوضع الحالي
├ قيد التنفيذ      : ${s.running}/${s.limits.concurrency}
├ مستخدمون نشطون   : ${s.activeUsers}
├ مجموعات نشطة     : ${s.activeThreads}
├ مفاتيح مُبرَّدة   : ${s.coolingKeys}
└ التشغيل منذ      : ${fmtUptime(s.uptimeSec)}

💾 الذاكرة
├ المستهلك         : ${s.memoryMB} MB
├ الحد الناعم      : ${s.limits.memorySoftMB} MB
├ الحد الأقصى      : ${s.limits.memoryHardMB} MB
└ ${memBar}

📏 الحدود
├ لكل مستخدم      : ${s.limits.perUser.max} / ${s.limits.perUser.windowMs/1000}s
├ لكل مجموعة      : ${s.limits.perThread.max} / ${s.limits.perThread.windowMs/1000}s
└ عام (نظام)      : ${s.limits.global.max} / ${s.limits.global.windowMs/1000}s`;

  return api.sendMessage(msg, event.threadID, event.messageID);
};
