const { exec } = require("child_process");
const fs = require("fs-extra");
const path = require("path");
const axios = require("axios");

module.exports.config = {
  name: "song",
  aliases: ["music", "play", "أغنية"],
  version: "3.0.0",
  permission: 0,
  credits: "Maro X bot",
  description: "تحميل الأغاني من YouTube",
  prefix: true,
  category: "Media",
  usages: "[اسم الأغنية]",
  cooldowns: 10
};

module.exports.run = async ({ api, event, args }) => {
  const { threadID, messageID } = event;

  try {
    if (args.length === 0) {
      return api.sendMessage(
        "⚠️ يرجى كتابة اسم الأغنية!\n\nمثال: -song Faded",
        threadID,
        messageID
      );
    }

    const songName = args.join(" ");
    
    api.sendMessage(
      `🔍 جاري البحث عن: ${songName}\n⏳ الرجاء الانتظار...`,
      threadID,
      async (err, info) => {
        try {
          // البحث عن الفيديو
          const searchAPI = `https://www.youtube.com/results?search_query=${encodeURIComponent(songName)}`;
          
          api.editMessage(
            `✅ تم العثور على الأغنية\n📥 جاري التحميل...`,
            info.messageID,
            threadID
          );

          const cacheDir = path.join(__dirname, "cache");
          if (!fs.existsSync(cacheDir)) {
            fs.mkdirSync(cacheDir, { recursive: true });
          }

          const fileName = `song_${Date.now()}.mp3`;
          const filePath = path.join(cacheDir, fileName);

          // استخدام yt-dlp للتحميل
          const ytdlpCommand = `yt-dlp -x --audio-format mp3 --audio-quality 128K -o "${filePath}" "ytsearch:${songName}" --no-playlist --no-warnings --quiet`;

          exec(ytdlpCommand, { timeout: 120000 }, async (error, stdout, stderr) => {
            if (error) {
              console.error("[Song Error]:", error);
              
              // محاولة API بديل
              try {
                const backupAPI = `https://api.popcat.xyz/youtube/search?q=${encodeURIComponent(songName)}`;
                const searchRes = await axios.get(backupAPI);
                
                if (searchRes.data && searchRes.data[0]) {
                  const video = searchRes.data[0];
                  const downloadAPI = `https://api.popcat.xyz/youtube/download?url=${encodeURIComponent(video.url)}`;
                  const downloadRes = await axios.get(downloadAPI);
                  
                  if (downloadRes.data && downloadRes.data.audio) {
                    const writer = fs.createWriteStream(filePath);
                    const response = await axios({
                      url: downloadRes.data.audio,
                      method: "GET",
                      responseType: "stream"
                    });

                    response.data.pipe(writer);

                    await new Promise((resolve, reject) => {
                      writer.on("finish", resolve);
                      writer.on("error", reject);
                    });

                    const stats = fs.statSync(filePath);
                    const fileSizeMB = (stats.size / (1024 * 1024)).toFixed(2);

                    if (stats.size > 26214400) {
                      fs.unlinkSync(filePath);
                      return api.editMessage(
                        `❌ حجم الملف كبير جداً (${fileSizeMB}MB)\n⚠️ الحد الأقصى: 25MB`,
                        info.messageID,
                        threadID
                      );
                    }

                    api.unsendMessage(info.messageID);

                    return api.sendMessage(
                      {
                        body: `━━━━━━━━━━━━━━━━━━━━\n🎵 ${video.title}\n━━━━━━━━━━━━━━━━━━━━\n\n` +
                              `📺 القناة: ${video.channel}\n` +
                              `⏱️ المدة: ${video.duration}\n` +
                              `📦 الحجم: ${fileSizeMB}MB\n\n` +
                              `✅ تم التحميل بنجاح!`,
                        attachment: fs.createReadStream(filePath)
                      },
                      threadID,
                      () => fs.unlinkSync(filePath),
                      messageID
                    );
                  }
                }
              } catch (backupError) {
                console.error("[Song Backup Error]:", backupError);
              }

              return api.editMessage(
                "❌ | حدث خطأ:\n" +
                `${error.message}\n\n` +
                "💡 تأكد من تثبيت yt-dlp على السيرفر.",
                info.messageID,
                threadID
              );
            }

            // التحقق من وجود الملف
            if (!fs.existsSync(filePath)) {
              return api.editMessage(
                "❌ فشل التحميل!\nجرب أغنية أخرى.",
                info.messageID,
                threadID
              );
            }

            const stats = fs.statSync(filePath);
            const fileSizeMB = (stats.size / (1024 * 1024)).toFixed(2);

            if (stats.size > 26214400) {
              fs.unlinkSync(filePath);
              return api.editMessage(
                `❌ حجم الملف كبير جداً (${fileSizeMB}MB)\n⚠️ الحد الأقصى: 25MB`,
                info.messageID,
                threadID
              );
            }

            api.unsendMessage(info.messageID);

            return api.sendMessage(
              {
                body: `━━━━━━━━━━━━━━━━━━━━\n🎵 ${songName}\n━━━━━━━━━━━━━━━━━━━━\n\n` +
                      `📦 الحجم: ${fileSizeMB}MB\n\n` +
                      `✅ تم التحميل بنجاح!`,
                attachment: fs.createReadStream(filePath)
              },
              threadID,
              () => {
                if (fs.existsSync(filePath)) {
                  fs.unlinkSync(filePath);
                }
              },
              messageID
            );
          });

        } catch (error) {
          console.error("[Song Main Error]:", error);
          return api.editMessage(
            "❌ حدث خطأ غير متوقع!\nيرجى المحاولة مرة أخرى.",
            info.messageID,
            threadID
          );
        }
      }
    );

  } catch (error) {
    console.error("[Song Error]:", error);
    return api.sendMessage(
      "❌ حدث خطأ!\nيرجى المحاولة مرة أخرى.",
      threadID,
      messageID
    );
  }
};
