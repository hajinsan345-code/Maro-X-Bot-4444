const shield = require("../../main/system/shield.js");

module.exports.config = {
  name: "antiband",
  version: "1.0.0",
  permission: 2,
  credits: "Maro X bot",
  prefix: true,
  premium: false,
  description: "نظام الحماية من الحظر (Anti-Ban Shield)",
  category: "admin",
  usages: "[status | on | off | wake | limit <n> | log]",
  cooldowns: 5,
  dependencies: {}
};

const RISK_EMOJI = { low: "🟢", medium: "🟡", high: "🔴", critical: "💀" };

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID } = event;
  const sub = (args[0] || "status").toLowerCase();

  // ── status ────────────────────────────────────────────────
  if (sub === "status") {
    const s = global.shield;
    if (!s) return api.sendMessage("⚠️ نظام الدرع غير مُحمَّل بعد.", threadID, messageID);

    const risk = s.riskLevel || "low";
    const emoji = RISK_EMOJI[risk] || "🟢";
    const sleepInfo = s.sleep.active
      ? `\n🔴 وضع السكون: نشط (${Math.ceil((s.sleep.until - Date.now()) / 1000)}ث متبقية)\n📋 السبب: ${s.sleep.reason}`
      : "\n🟢 وضع السكون: معطّل";

    const msg =
      `╔══ 🛡️ نظام الحماية من الحظر ══╗\n` +
      `${emoji} مستوى الخطر    : ${risk.toUpperCase()}\n` +
      `⚡ الحالة        : ${s.enabled ? "✅ مفعّل" : "❌ معطّل"}\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `📤 هذه الدقيقة  : ${s.stats.sentThisMinute}/${s.limits.maxPerMinute}\n` +
      `📊 هذه الساعة   : ${s.stats.sentThisHour}/${s.limits.maxPerHour}\n` +
      `📬 إجمالي مُرسَل : ${s.stats.totalSent}\n` +
      `⚠️ عدد الأخطاء  : ${s.errors.count}/${s.limits.errorThreshold}\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `⚙️ الحد/الدقيقة : ${s.limits.maxPerMinute} رسالة\n` +
      `⚙️ الحد/الساعة  : ${s.limits.maxPerHour} رسالة\n` +
      `⚙️ التكرار max  : ${s.limits.duplicateMaxCount}x/${s.limits.duplicateWindow / 1000}ث\n` +
      `⚙️ مدة السكون   : ${s.limits.sleepDuration / 1000}ث` +
      sleepInfo + `\n` +
      `╚══════════════════════════╝`;

    return api.sendMessage(msg, threadID, messageID);
  }

  // ── on ────────────────────────────────────────────────────
  if (sub === "on") {
    global.shield.enabled = true;
    shield.addLog("MANUAL", "تم تفعيل الحماية يدوياً");
    return api.sendMessage("✅ نظام الحماية من الحظر مفعّل.", threadID, messageID);
  }

  // ── off ───────────────────────────────────────────────────
  if (sub === "off") {
    global.shield.enabled = false;
    shield.addLog("MANUAL", "تم تعطيل الحماية يدوياً");
    return api.sendMessage("⚠️ نظام الحماية من الحظر معطّل.\nتحذير: قد يتعرض الحساب للحظر!", threadID, messageID);
  }

  // ── wake (إيقاظ من السكون) ───────────────────────────────
  if (sub === "wake") {
    if (!global.shield.sleep.active) {
      return api.sendMessage("ℹ️ البوت يعمل بشكل طبيعي، لا يوجد سكون.", threadID, messageID);
    }
    shield.forceWake();
    return api.sendMessage("✅ تم إيقاظ البوت من وضع السكون وإعادة تعيين العداد.", threadID, messageID);
  }

  // ── limit <n> (تغيير حد الدقيقة) ─────────────────────────
  if (sub === "limit") {
    const n = parseInt(args[1]);
    if (!n || n < 1 || n > 60) {
      return api.sendMessage("⚠️ أدخل رقماً بين 1 و 60.\nمثال: -antiband limit 15", threadID, messageID);
    }
    global.shield.limits.maxPerMinute = n;
    shield.addLog("CONFIG", `تم تغيير حد الدقيقة إلى ${n}`);
    return api.sendMessage(`✅ تم ضبط حد الرسائل على ${n} رسالة/دقيقة.`, threadID, messageID);
  }

  // ── log ───────────────────────────────────────────────────
  if (sub === "log") {
    const logs = global.shield.log.slice(0, 10);
    if (!logs.length) return api.sendMessage("📋 السجل فارغ.", threadID, messageID);

    const lines = logs.map((l, i) => {
      const t = new Date(l.time).toLocaleTimeString("ar-SA");
      return `${i + 1}. [${t}] ${l.type}\n   ${l.detail}`;
    }).join("\n\n");

    return api.sendMessage(`📋 آخر 10 أحداث في سجل الحماية:\n\n${lines}`, threadID, messageID);
  }

  // ── مساعدة ───────────────────────────────────────────────
  return api.sendMessage(
    `🛡️ نظام الحماية من الحظر\n\n` +
    `-antiband status       — حالة النظام الكاملة\n` +
    `-antiband on           — تفعيل الحماية\n` +
    `-antiband off          — تعطيل الحماية\n` +
    `-antiband wake         — إيقاظ البوت من وضع السكون\n` +
    `-antiband limit [1-60] — ضبط حد الرسائل بالدقيقة\n` +
    `-antiband log          — عرض سجل الأحداث`,
    threadID, messageID
  );
};
