module.exports.config = {
  name: "protect",
  version: "2.2.0",
  permission: 1,
  credits: "Maro X bot",
  description: "حماية اسم المجموعة والكنيات من المخربين",
  prefix: true,
  category: "admin",
  usages: "protect on [اسم] | protect nickall on [كنية] | protect nickall clear | protect off | protect nickall off | protect status",
  cooldowns: 3,
  premium: false,
  dependencies: {}
};

if (!global.protectData) {
  global.protectData = {
    threadName: new Map(),
    nickall: new Map()
  };
}

module.exports.run = async function ({ api, event, args }) {
  const threadID = String(event.threadID);
  const sub = (args[0] || "").toLowerCase();
  const action = (args[1] || "").toLowerCase();

  if (sub === "status") {
    const nameInfo = global.protectData.threadName.get(threadID);
    const nickInfo = global.protectData.nickall.get(threadID);
    const nameStatus = nameInfo?.enabled
      ? `✅ مفعّل`
      : "❌ معطّل";

    let nickStatus = "❌ معطّل";
    if (nickInfo?.enabled) {
      nickStatus = nickInfo.mode === "clear"
        ? `✅ مفعّل (وضع المسح التلقائي)`
        : `✅ مفعّل (الكنية: ${nickInfo.desiredNick})`;
    }

    return api.sendMessage(
      `🛡️ حالة الحماية في هذه المجموعة:\n\n📛 اسم المجموعة: ${nameStatus}\n\n🏷️ الكنيات: ${nickStatus}`,
      threadID, event.messageID
    );
  }

  if (sub === "nickall") {

    // ─── وضع المسح التلقائي ────────────────────────────────────────────────
    if (action === "clear") {
      const subAction = (args[2] || "").toLowerCase();

      if (subAction === "off") {
        if (global.protectData.nickall.has(threadID)) {
          global.protectData.nickall.get(threadID).enabled = false;
        }
        return api.sendMessage("✅ تم إيقاف وضع مسح الكنيات التلقائي.", threadID, event.messageID);
      }

      // تفعيل وضع المسح (on أو بدون مفتاح)
      let threadInfo;
      try { threadInfo = await api.getThreadInfo(threadID); } catch (e) {
        return api.sendMessage("⚠️ تعذّر جلب معلومات المجموعة.", threadID, event.messageID);
      }
      
      const participants = threadInfo.participantIDs || [];
      const totalMembers = participants.length;
      
      // إرسال رسالة البداية
      const startMsg = await api.sendMessage(
        `🧹 جاري مسح الكنيات...\n⏳ التقدم: 0/${totalMembers} (0%)`,
        threadID
      );
      
      let cleared = 0;
      for (let i = 0; i < participants.length; i++) {
        const uid = participants[i];
        try {
          await api.changeNickname("", threadID, uid);
          cleared++;
          
          // تحديث التقدم كل 5 أعضاء
          if ((i + 1) % 5 === 0 || i === participants.length - 1) {
            const progress = Math.round(((i + 1) / totalMembers) * 100);
            await api.editMessage(
              `🧹 جاري مسح الكنيات...\n⏳ التقدم: ${i + 1}/${totalMembers} (${progress}%)`,
              startMsg.messageID
            );
          }
          
          // تأخير 5 ثوانٍ بين كل عملية
          await new Promise(resolve => setTimeout(resolve, 5000));
        } catch (e) {
          console.log(`فشل مسح كنية ${uid}: ${e.message}`);
        }
      }
      
      global.protectData.nickall.set(threadID, { enabled: true, mode: "clear" });
      
      return api.editMessage(
        `✅ تم تفعيل وضع مسح الكنيات التلقائي!\n👥 تم مسح كنية ${cleared} عضو.\nسيتم مسح أي كنية جديدة تلقائياً عند تغييرها.\n\nللإيقاف: -protect nickall clear off`,
        startMsg.messageID
      );
    }

    // ─── وضع الحماية بكنية محددة ──────────────────────────────────────────
    if (action === "on") {
      const desiredNick = args.slice(2).join(" ").trim();
      if (!desiredNick) {
        return api.sendMessage(
          "⚠️ يجب إدخال الكنية المرغوبة.\nمثال: -protect nickall on ملك البوت",
          threadID, event.messageID
        );
      }
      
      let threadInfo;
      try { threadInfo = await api.getThreadInfo(threadID); } catch (e) {
        return api.sendMessage("⚠️ تعذّر جلب معلومات المجموعة.", threadID, event.messageID);
      }
      
      const participants = threadInfo.participantIDs || [];
      const totalMembers = participants.length;
      
      // إرسال رسالة البداية
      const startMsg = await api.sendMessage(
        `🏷️ جاري تطبيق الكنية...\n⏳ التقدم: 0/${totalMembers} (0%)`,
        threadID
      );
      
      let changed = 0;
      for (let i = 0; i < participants.length; i++) {
        const uid = participants[i];
        try {
          await api.changeNickname(desiredNick, threadID, uid);
          changed++;
          
          // تحديث التقدم كل 5 أعضاء
          if ((i + 1) % 5 === 0 || i === participants.length - 1) {
            const progress = Math.round(((i + 1) / totalMembers) * 100);
            await api.editMessage(
              `🏷️ جاري تطبيق الكنية...\n⏳ التقدم: ${i + 1}/${totalMembers} (${progress}%)`,
              startMsg.messageID
            );
          }
          
          // تأخير 5 ثوانٍ بين كل عملية
          await new Promise(resolve => setTimeout(resolve, 5000));
        } catch (e) {
          console.log(`فشل تغيير كنية ${uid}: ${e.message}`);
        }
      }
      
      const nicknames = new Map();
      for (const uid of participants) {
        nicknames.set(String(uid), desiredNick);
      }
      
      global.protectData.nickall.set(threadID, { enabled: true, mode: "protect", desiredNick, nicknames });
      
      return api.editMessage(
        `✅ تم تفعيل حماية الكنيات!\n👥 تم تطبيق الكنية على ${changed} عضو.\nسيتم استعادتها تلقائياً عند أي تغيير.`,
        startMsg.messageID
      );
    }

    if (action === "off") {
      if (global.protectData.nickall.has(threadID)) {
        global.protectData.nickall.get(threadID).enabled = false;
      }
      return api.sendMessage("✅ تم إيقاف حماية الكنيات.", threadID, event.messageID);
    }

    return api.sendMessage(
      "📌 استخدام:\n-protect nickall on [كنية] — تفعيل حماية الكنيات بكنية محددة\n-protect nickall clear — مسح جميع الكنيات وإيقاف أي كنية جديدة تلقائياً\n-protect nickall clear off — إيقاف وضع المسح\n-protect nickall off — إيقاف الحماية\n\nمثال:\n-protect nickall on ملك البوت\n-protect nickall clear",
      threadID, event.messageID
    );
  }

  if (sub === "on") {
    const desiredName = args.slice(1).join(" ").trim();
    if (!desiredName) {
      return api.sendMessage(
        "⚠️ يجب إدخال الاسم المرغوب للمجموعة.\nمثال: -protect on اسم مجموعتي",
        threadID, event.messageID
      );
    }
    try {
      await api.setTitle(desiredName, threadID);
    } catch (e) {}
    global.protectData.threadName.set(threadID, { enabled: true, originalName: desiredName });
    return api.sendMessage(
      `✅ تم تفعيل حماية اسم المجموعة!\n📛 تم ضبط الاسم وحمايته بنجاح.\nسيتم استعادته تلقائياً عند أي تغيير.`,
      threadID, event.messageID
    );
  }

  if (sub === "off") {
    if (global.protectData.threadName.has(threadID)) {
      global.protectData.threadName.get(threadID).enabled = false;
    }
    return api.sendMessage("✅ تم إيقاف حماية اسم المجموعة.", threadID, event.messageID);
  }

  return api.sendMessage(
    `📌 طريقة الاستخدام:\n\n-protect on [اسم] — ضبط اسم المجموعة وحمايته\n-protect off — إيقاف حماية الاسم\n-protect nickall on [كنية] — ضبط كنية لجميع الأعضاء وحمايتها\n-protect nickall clear — مسح جميع الكنيات ومنع أي كنية جديدة\n-protect nickall clear off — إيقاف وضع المسح\n-protect nickall off — إيقاف حماية الكنيات\n-protect status — عرض حالة الحماية\n\nأمثلة:\n-protect on مجموعة الملوك\n-protect nickall on عضو مميز\n-protect nickall clear`,
    threadID, event.messageID
  );
};
