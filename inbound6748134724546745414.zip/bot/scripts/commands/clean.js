module.exports = {
  config: {
    name: "clean",
    version: "1.0",
    author: "Monica",
    role: 1, // 1 يعني أدمن
    shortDescription: "طرد الحسابات المعطلة",
    longDescription: "يقوم البوت بفحص المجموعة وطرد الحسابات المعطلة (Facebook User)",
    category: "admin",
    guide: "{pn}"
  },

  onStart: async function ({ api, event }) {
    const { threadID, senderID } = event;

    const info = await new Promise(resolve => api.getThreadInfo(threadID, (err, res) => resolve(res)));
    
    // التحقق من صلاحية الأدمن
    if (!info.adminIDs.some(admin => admin.id === senderID)) {
      return api.sendMessage("❌ هذا الأمر للمشرفين فقط.", threadID);
    }

    api.sendMessage("🔍 جاري فحص الأعضاء المعطلين، يرجى الانتظار...", threadID, async () => {
      let kickedCount = 0;
      const participants = info.participantIDs;

      for (const userID of participants) {
        try {
          const userInfo = await new Promise(resolve => api.getUserInfo(userID, (err, res) => resolve(res)));
          if (!userInfo || !userInfo[userID] || !userInfo[userID].name) {
            await new Promise(resolve => api.removeUserFromGroup(userID, threadID, () => resolve()));
            kickedCount++;
          }
        } catch (e) {}
      }

      api.sendMessage(kickedCount > 0 ? `✅ تم تنظيف المجموعة! تم طرد ${kickedCount} حساب معطل.` : "✨ المجموعة نظيفة، لا توجد حسابات معطلة.", threadID);
    });
  }
};
