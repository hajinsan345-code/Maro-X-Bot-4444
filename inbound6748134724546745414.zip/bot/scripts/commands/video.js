const axios = require("axios");
const fs = require("fs-extra");
const path = require("path");
const { spawn } = require("child_process");
const os = require("os");

module.exports.config = {
  name: "video",
  version: "5.0.0",
  permission: 0,
  credits: "Maro X bot",
  description: "ابحث وحمّل فيديو من يوتيوب بجودة 360p",
  prefix: true,
  category: "media",
  usages: "video [اسم الفيديو]",
  cooldowns: 8
};

const LOCAL_YTDLP = path.join(__dirname, "..", "..", "bin", "yt-dlp");
const YTDLP = fs.existsSync(LOCAL_YTDLP) ? LOCAL_YTDLP : "yt-dlp";
const CACHE_DIR = path.join(os.tmpdir(), "maroxbot-cache");

async function searchYouTube(query) {
  const sources = [
    async () => {
      const res = await axios.get(
        `https://betadash-search-download.vercel.app/yt?search=${encodeURIComponent(query)}`,
        { timeout: 12000 }
      );
      const item = res.data?.[0];
      if (item?.url) return { title: item.title, url: item.url.replace(/\?si=.*/, ""), duration: item.time || "" };
    },
    async () => {
      const res = await axios.get(
        `https://www.googleapis.com/youtube/v3/search?part=snippet&q=${encodeURIComponent(query)}&type=video&maxResults=1&key=AIzaSyCqox-KXEwDncsuo2HIpE0MF8J7ATln5Vc`,
        { timeout: 8000 }
      );
      const item = res.data?.items?.[0];
      if (item) return { title: item.snippet.title, url: `https://www.youtube.com/watch?v=${item.id.videoId}`, duration: "" };
    }
  ];

  for (const fn of sources) {
    try {
      const r = await fn();
      if (r?.url) return r;
    } catch (e) { continue; }
  }
  return null;
}

function ytdlDownloadVideo(ytUrl, outPath) {
  return new Promise((resolve, reject) => {
    const args = [
      "-f", "bestvideo[height<=360][ext=mp4]+bestaudio[ext=m4a]/bestvideo[height<=480][ext=mp4]+bestaudio[ext=m4a]/best[height<=480][ext=mp4]/best[ext=mp4]/best",
      "--merge-output-format", "mp4",
      "--no-playlist",
      "--no-warnings",
      "--no-progress",
      "--max-filesize", "80m",
      "-o", outPath,
      ytUrl
    ];
    const proc = spawn(YTDLP, args, { timeout: 180000 });
    let stderr = "";
    proc.stderr.on("data", d => { stderr += d.toString(); });
    proc.on("close", code => {
      if (code === 0) resolve(outPath.replace("%(ext)s", "mp4"));
      else reject(new Error(stderr.slice(-300)));
    });
    proc.on("error", reject);
  });
}

module.exports.run = async ({ api, event, args }) => {
  const { threadID, messageID } = event;
  const query = args.join(" ").trim();

  if (!query) {
    return api.sendMessage(
      "⚠️ أرسل اسم الفيديو!\n📌 مثال: -video Blinding Lights",
      threadID, messageID
    );
  }

  let loadingID = null;
  let filePath = null;

  try {
    const loadingMsg = await api.sendMessage(
      `🔍 جارٍ البحث عن: "${query}"\n⏳ انتظر لحظة...`,
      threadID
    );
    loadingID = loadingMsg?.messageID;

    const video = await searchYouTube(query);

    if (!video) {
      if (loadingID) await api.unsendMessage(loadingID).catch(() => {});
      return api.sendMessage(
        "❌ لم أجد نتائج لهذا البحث.\nجرّب كلمات مختلفة.",
        threadID, messageID
      );
    }

    try { await api.editMessage(`✅ وُجد: ${video.title}\n⬇️ جارٍ التحميل...`, loadingID); } catch (e) {}

    await fs.ensureDir(CACHE_DIR);
    const timestamp = Date.now();
    const outTemplate = path.join(CACHE_DIR, `vid_${timestamp}.%(ext)s`);

    filePath = await ytdlDownloadVideo(video.url, outTemplate);

    if (!await fs.pathExists(filePath)) throw new Error("file not found after download");

    if (loadingID) await api.unsendMessage(loadingID).catch(() => {});

    await api.sendMessage(
      {
        body: `━━━━━━━━━━━━━━━━\n🎬 ${video.title}${video.duration ? `\n⏱️ المدة: ${video.duration}` : ""}\n━━━━━━━━━━━━━━━━\n✅ استمتع بالفيديو!`,
        attachment: fs.createReadStream(filePath)
      },
      threadID,
      async () => { if (filePath) await fs.unlink(filePath).catch(() => {}); },
      messageID
    );

  } catch (err) {
    if (filePath) await fs.unlink(filePath).catch(() => {});
    if (loadingID) await api.unsendMessage(loadingID).catch(() => {});
    api.sendMessage(
      "⚠️ حدث خطأ أثناء تحميل الفيديو. حاول مجدداً.",
      threadID, messageID
    );
  }
};
