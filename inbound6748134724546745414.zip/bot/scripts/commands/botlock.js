const fs = require("fs");
const path = require("path");

const CONFIG_PATH = path.join(__dirname, "..", "..", "Config.json");

module.exports.config = {
  name: "botlock",
  version: "1.0.0",
  permission: 3,
  credits: "Maro X bot",
  description: "فتح أو إغلاق البوت — للمالك فقط",
  prefix: true,
  premium: false,
  category: "Owner",
  usages: "botlock [on/off/status]",
  cooldowns: 2,
};

function saveConfig(config) {
  fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2), "utf8");
}

module.exports.run = async ({ api, event, args }) => {
  const { threadID, messageID, senderID } = event;
  const { OWNER } = global.config;

  const sid = String(senderID);
  const isOwner = OWNER.some((o) => String(o) === sid);
  if (!isOwner) {
    return api.sendMessage("⛔ هذا الأمر للمالك فقط.", threadID, messageID);
  }

  const sub = (args[0] || "").toLowerCase().trim();
  const isLocked = global.config.botLock === true;

  if (!sub || sub === "status") {
    const status = isLocked
      ? "🔒 البوت مغلق — يعمل للمالك فقط."
      : "🔓 البوت مفتوح — يعمل للجميع.";
    return api.sendMessage(
      `━━━━━━━━━━━━━━\n${status}\n━━━━━━━━━━━━━━\n📌 لتغيير الحالة:\n   -botlock on  → إغلاق للمالك فقط\n   -botlock off → فتح للجميع`,
      threadID,
      messageID,
    );
  }

  if (sub === "on") {
    if (isLocked) {
      return api.sendMessage("🔒 البوت مغلق بالفعل.", threadID, messageID);
    }
    global.config.botLock = true;
    saveConfig(global.config);
    return api.sendMessage(
      "🔒 تم إغلاق البوت.\n✅ الآن يستجيب للمالك فقط.\nللفتح: -botlock off",
      threadID,
      messageID,
    );
  }

  if (sub === "off") {
    if (!isLocked) {
      return api.sendMessage("🔓 البوت مفتوح بالفعل.", threadID, messageID);
    }
    global.config.botLock = false;
    saveConfig(global.config);
    return api.sendMessage(
      "🔓 تم فتح البوت.\n✅ الآن يستجيب للجميع.\nللإغلاق: -botlock on",
      threadID,
      messageID,
    );
  }

  return api.sendMessage(
    "⚠️ أمر غير صحيح.\n📌 الاستخدام:\n   -botlock on      → إغلاق للمالك فقط\n   -botlock off     → فتح للجميع\n   -botlock status  → عرض الحالة الحالية",
    threadID,
    messageID,
  );
};
