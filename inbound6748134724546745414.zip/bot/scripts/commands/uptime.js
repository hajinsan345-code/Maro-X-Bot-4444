const moment = require("moment-timezone");
const pidusage = require("pidusage");
const { performance } = require("perf_hooks");
const os = require("os");
const path = require("path");
const fs = require("fs");
const https = require("https");

function pingHost(hostname, timeout = 5000) {
  return new Promise(resolve => {
    const start = Date.now();
    const req = https.request(
      { host: hostname, port: 443, method: "HEAD", path: "/", timeout },
      res => {
        const latency = Date.now() - start;
        res.resume();
        resolve({ ok: true, latency, status: res.statusCode });
      }
    );
    req.on("timeout", () => { req.destroy(); resolve({ ok: false, latency: timeout, status: 0 }); });
    req.on("error", () => resolve({ ok: false, latency: Date.now() - start, status: 0 }));
    req.end();
  });
}

function getNetworkInfo() {
  const ifaces = os.networkInterfaces();
  let activeIface = "unknown", localIp = "0.0.0.0";

  for (const [name, addrs] of Object.entries(ifaces)) {
    if (!addrs) continue;
    for (const addr of addrs) {
      if (addr.family === "IPv4" && !addr.internal) {
        activeIface = name;
        localIp = addr.address;
        break;
      }
    }
    if (activeIface !== "unknown") break;
  }
  return { activeIface, localIp };
}

moment.tz.setDefault("Asia/Dhaka");

module.exports.config = {
  name: "uptime",
  version: "2.1.0",
  permission: 0,
  credits: "Maro X bot",
  description: "حالة البوت بتصميم terminal أخضر",
  prefix: true,
  category: "info",
  usages: "uptime",
  cooldowns: 5,
  dependencies: { "moment-timezone": "latest", pidusage: "latest", pureimage: "latest" }
};

const FONT_REG  = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf";
const FONT_BOLD = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf";

async function buildImage(data) {
  const PImage = require("pureimage");

  // register both fonts with separate names
  await PImage.registerFont(fs.existsSync(FONT_REG)  ? FONT_REG  : FONT_BOLD, "Mono").load();
  await PImage.registerFont(fs.existsSync(FONT_BOLD) ? FONT_BOLD : FONT_REG,  "MonoBold").load();

  const W = 800, H = 760;
  const img = PImage.make(W, H);
  const ctx = img.getContext("2d");

  // ── background ─────────────────────────────────────────────────
  ctx.fillStyle = "#050f05";
  ctx.fillRect(0, 0, W, H);

  // ── scanlines ──────────────────────────────────────────────────
  for (let y = 0; y < H; y += 4) {
    ctx.fillStyle = "rgba(0,10,0,0.45)";
    ctx.fillRect(0, y, W, 2);
  }

  // ── outer border (bright green) ────────────────────────────────
  ctx.fillStyle = "#00ff41";
  ctx.fillRect(10, 10, W - 20, 2);
  ctx.fillRect(10, H - 12, W - 20, 2);
  ctx.fillRect(10, 10, 2, H - 20);
  ctx.fillRect(W - 12, 10, 2, H - 20);

  // ── inner border (dim green) ────────────────────────────────────
  ctx.fillStyle = "#003d10";
  ctx.fillRect(15, 15, W - 30, 1);
  ctx.fillRect(15, H - 16, W - 30, 1);
  ctx.fillRect(15, 15, 1, H - 30);
  ctx.fillRect(W - 16, 15, 1, H - 30);

  // ── corner L-brackets ─────────────────────────────────────────
  const cs = 20;
  ctx.fillStyle = "#00ff41";
  [ [10,10,1,1], [W-10-cs,10,1,1], [10,H-10-cs,1,1], [W-10-cs,H-10-cs,1,1] ]
    .forEach(([x, y]) => {
      ctx.fillRect(x, y, cs, 3);
      ctx.fillRect(x, y, 3, cs);
    });

  // ── header band ────────────────────────────────────────────────
  ctx.fillStyle = "#001a06";
  ctx.fillRect(12, 12, W - 24, 56);

  // ── online indicator square ────────────────────────────────────
  ctx.fillStyle = "#00ffaa";
  ctx.fillRect(28, 28, 14, 14);
  ctx.fillStyle = "#003d10";
  ctx.fillRect(W - 42, 28, 14, 14);

  // ── header text ────────────────────────────────────────────────
  ctx.font = "20px MonoBold";
  ctx.fillStyle = "#7fff7f";
  ctx.textAlign = "center";
  ctx.fillText("[ Maro X bot  //  SYSTEM MONITOR ]", W / 2, 50);
  ctx.textAlign = "left";

  // ── header bottom line ─────────────────────────────────────────
  ctx.fillStyle = "#007520";
  ctx.fillRect(16, 68, W - 32, 1);

  // ── vertical divider ───────────────────────────────────────────
  const MID = Math.floor(W / 2);
  ctx.fillStyle = "#002a0a";
  ctx.fillRect(MID, 74, 1, H - 148);

  // ── footer top line ────────────────────────────────────────────
  ctx.fillStyle = "#007520";
  ctx.fillRect(16, H - 62, W - 32, 1);

  // ── draw a data row ─────────────────────────────────────────────
  // label: small dim green   value: large bright green
  function row(label, value, x, y, valColor) {
    ctx.font = "13px Mono";
    ctx.fillStyle = "#00aa33";
    ctx.fillText(">  " + label, x, y);

    ctx.font = "19px MonoBold";
    ctx.fillStyle = valColor || "#00ff41";
    ctx.fillText(String(value), x, y + 24);
  }

  // ── left column ────────────────────────────────────────────────
  const LX = 36, RX = MID + 24;
  const TOP = 98, STEP = 64;

  row("UPTIME",   data.uptime,             LX, TOP + 0 * STEP);
  row("PING",     data.ping + " ms",        LX, TOP + 1 * STEP, data.ping < 300 ? "#00ffaa" : "#ffbb00");
  row("RAM USED", data.ramUsed,             LX, TOP + 2 * STEP);
  row("RAM FREE", data.ramFree,             LX, TOP + 3 * STEP);
  row("BOT RAM",  data.botRam,              LX, TOP + 4 * STEP, "#aaffcc");
  row("CPU LOAD", data.cpu,                 LX, TOP + 5 * STEP);
  row("CORES",    data.cores + " cores",    LX, TOP + 6 * STEP, "#aaffcc");

  row("STATUS",   "[ ONLINE ]",             RX, TOP + 0 * STEP, "#00ffaa");
  row("BOT ID",   data.botId,               RX, TOP + 1 * STEP, "#aaffcc");
  row("COMMANDS", data.commands + " cmds",  RX, TOP + 2 * STEP);
  row("GROUPS",   data.groups + " groups",  RX, TOP + 3 * STEP);
  row("USERS",    data.users + " users",    RX, TOP + 4 * STEP);
  row("PLATFORM", data.platform,            RX, TOP + 5 * STEP, "#aaffcc");
  row("NODE JS",  "v" + process.versions.node, RX, TOP + 6 * STEP, "#aaffcc");

  // ── CPU model row (full width at bottom) ───────────────────────
  ctx.font = "13px Mono";
  ctx.fillStyle = "#00aa33";
  ctx.fillText(">  CPU MODEL", LX, TOP + 7 * STEP - 6);
  ctx.font = "15px MonoBold";
  ctx.fillStyle = "#aaffcc";
  ctx.fillText(String(data.cpuModel), LX, TOP + 7 * STEP + 16);

  // ── NETWORK SECTION ─────────────────────────────────────────────
  const NET_Y = TOP + 7 * STEP + 50;

  // section divider
  ctx.fillStyle = "#007520";
  ctx.fillRect(16, NET_Y - 4, W - 32, 1);

  // section title
  ctx.font = "14px MonoBold";
  ctx.fillStyle = "#7fff7f";
  ctx.fillText("─[ NETWORK STATUS ]─", LX, NET_Y + 18);

  // network rows (2 per side)
  const NET_TOP = NET_Y + 40;
  const NET_STEP = 50;

  row("FB PING",   data.fbPing + " ms",  LX, NET_TOP + 0 * NET_STEP, data.fbPing < 500 ? "#00ffaa" : "#ffbb00");
  row("INTERFACE", data.netIface,         LX, NET_TOP + 1 * NET_STEP, "#aaffcc");
  row("IP ADDR",   data.localIp,          RX, NET_TOP + 0 * NET_STEP, "#aaffcc");
  row("FB STATUS", data.fbStatus,         RX, NET_TOP + 1 * NET_STEP, data.fbStatus === "[ CONNECTED ]" ? "#00ffaa" : "#ff5050");

  // ── matrix rain decoration (top-right area) ─────────────────────
  const MC = "01アイウエオカキクサシ01";
  ctx.font = "10px Mono";
  for (let c = 0; c < 10; c++) {
    for (let r = 0; r < 5; r++) {
      ctx.fillStyle = "rgba(0,255,65,0.10)";
      ctx.fillText(MC[Math.floor(Math.random() * MC.length)], W - 145 + c * 13, 78 + r * 11);
    }
  }

  // ── footer ──────────────────────────────────────────────────────
  ctx.font = "13px Mono";
  ctx.fillStyle = "#00aa33";
  ctx.textAlign = "center";
  ctx.fillText(
    data.time + "   ·   " + data.date + "   ·   Maro X bot v1.0.0",
    W / 2, H - 36
  );
  ctx.textAlign = "left";

  // ── save ────────────────────────────────────────────────────────
  const tmpPath = path.join(
    __dirname, "..", "..", "main", "botdata",
    `status_${Date.now()}.png`
  );
  await PImage.encodePNGToStream(img, fs.createWriteStream(tmpPath));
  return tmpPath;
}

module.exports.run = async ({ api, event }) => {
  const { threadID, messageID } = event;
  let tmpFile = null;

  try {
    const t0 = performance.now();

    let cpu = "N/A", ramUsed = "N/A", ramFree = "N/A";
    try {
      const u = await pidusage(process.pid);
      cpu     = u.cpu.toFixed(1) + "%";
      ramUsed = ((os.totalmem() - os.freemem()) / 1048576).toFixed(0) + " MB";
      ramFree = (os.freemem() / 1048576).toFixed(0) + " MB";
    } catch (_) {}

    const sec  = process.uptime();
    const ping = Math.round(performance.now() - t0);

    // ── جمع معلومات الشبكة بالتوازي ──────────────────────────────
    const [fbResult, netInfo] = await Promise.all([
      pingHost("www.facebook.com", 5000),
      Promise.resolve(getNetworkInfo())
    ]);

    const cpus = os.cpus();
    const cpuModel = (cpus[0]?.model || "Unknown CPU")
      .replace(/\s+/g, " ").trim().slice(0, 60);

    const data = {
      uptime:   `${Math.floor(sec/3600)}h ${Math.floor((sec%3600)/60)}m ${Math.floor(sec%60)}s`,
      ping,
      ramUsed,
      ramFree,
      botRam:   (process.memoryUsage().rss / 1048576).toFixed(0) + " MB",
      cpu,
      cores:    cpus.length,
      cpuModel,
      platform: `${process.platform} ${process.arch}`,
      botId:    String(api.getCurrentUserID()).replace(/(\d{4})\d+(\d{4})/, "$1...$2"),
      commands: global.client?.commands?.size || 0,
      groups:   global.data?.allThreadID?.length || 0,
      users:    global.data?.allUserID?.length || 0,
      time:     moment().format("HH:mm:ss"),
      date:     moment().format("DD/MM/YYYY"),
      // network
      fbPing:   fbResult.latency,
      fbStatus: fbResult.ok ? "[ CONNECTED ]" : "[ DISCONNECTED ]",
      netIface: netInfo.activeIface,
      localIp:  netInfo.localIp,
    };

    tmpFile = await buildImage(data);
    await api.sendMessage({ attachment: fs.createReadStream(tmpFile) }, threadID, messageID);

  } catch (err) {
    const sec = process.uptime();
    const mem = (process.memoryUsage().heapUsed / 1048576).toFixed(0);
    api.sendMessage(
      `╔══ BOT STATUS ══╗\n` +
      `║ Uptime : ${Math.floor(sec/3600)}h ${Math.floor((sec%3600)/60)}m ${Math.floor(sec%60)}s\n` +
      `║ RAM    : ${mem} MB\n` +
      `║ CMD    : ${global.client?.commands?.size || 0}\n` +
      `║ Groups : ${global.data?.allThreadID?.length || 0}\n` +
      `║ Users  : ${global.data?.allUserID?.length || 0}\n` +
      `║ Time   : ${moment().format("HH:mm:ss DD/MM/YYYY")}\n` +
      `╚════════════════╝`,
      threadID, messageID
    );
  } finally {
    if (tmpFile) setTimeout(() => { try { fs.unlinkSync(tmpFile); } catch (_) {} }, 6000);
  }
};
