module.exports.config = {
  name: "kick",
  version: "2.0.0",
  permission: 1,
  prefix: true,
  credits: "Maro X bot",
  description: "طرد عضو أو أكثر من المجموعة عن طريق المنشن",
  category: "admin",
  usages: "kick [@منشن] [@منشن2] ...",
  cooldowns: 3,
  premium: false,
  dependencies: {}
};

module.exports.run = async function ({ api, event }) {
  const threadID = event.threadID;
  const senderID = String(event.senderID);
  const botID = String(api.getCurrentUserID());
  const mentions = Object.keys(event.mentions || {});

  let threadInfo;
  try {
    threadInfo = await api.getThreadInfo(threadID);
  } catch (e) {
    return api.sendMessage("⚠️ تعذّر جلب معلومات المجموعة.", threadID, event.messageID);
  }

  const adminIDs = (threadInfo.adminIDs || []).map(a => String(a.id));

  if (!adminIDs.includes(botID)) {
    return api.sendMessage(
      "❌ البوت ليس مشرفاً في هذه المجموعة.\nيجب تعيين البوت كمشرف أولاً لاستخدام هذا الأمر.",
      threadID, event.messageID
    );
  }

  if (!adminIDs.includes(senderID)) {
    return api.sendMessage(
      "❌ هذا الأمر مخصص للمشرفين فقط.",
      threadID, event.messageID
    );
  }

  if (mentions.length === 0) {
    return api.sendMessage(
      "⚠️ يجب منشنة عضو واحد على الأقل لطرده.\n\nمثال: -kick @اسم_العضو",
      threadID, event.messageID
    );
  }

  const toKick = mentions.filter(uid => {
    if (uid === botID) return false;
    if (adminIDs.includes(String(uid))) return false;
    return true;
  });

  const skippedAdmins = mentions.filter(uid => uid !== botID && adminIDs.includes(String(uid)));
  const skippedBot = mentions.includes(botID);

  if (toKick.length === 0) {
    let msg = "⚠️ لم يتم طرد أي عضو.";
    if (skippedBot) msg += "\n• لا يمكن طرد البوت من نفسه.";
    if (skippedAdmins.length > 0) msg += "\n• لا يمكن طرد المشرفين.";
    return api.sendMessage(msg, threadID, event.messageID);
  }

  let kicked = 0;
  let failed = 0;

  for (const uid of toKick) {
    try {
      await new Promise((resolve, reject) => {
        setTimeout(async () => {
          try {
            await api.removeUserFromGroup(uid, threadID);
            kicked++;
            resolve();
          } catch (e) {
            failed++;
            resolve();
          }
        }, kicked * 1500);
      });
    } catch (e) {
      failed++;
    }
  }

  let resultMsg = `✅ تم طرد ${kicked} عضو بنجاح.`;
  if (failed > 0) resultMsg += `\n⚠️ فشل طرد ${failed} عضو.`;
  if (skippedAdmins.length > 0) resultMsg += `\n🛡️ تم تجاهل ${skippedAdmins.length} مشرف (لا يمكن طرد المشرفين).`;
  if (skippedBot) resultMsg += `\n🤖 لا يمكن للبوت طرد نفسه.`;

  return api.sendMessage(resultMsg, threadID, event.messageID);
};
