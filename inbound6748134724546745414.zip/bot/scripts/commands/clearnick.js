module.exports.config = {
  name: "clearnick",
  version: "1.0.0",
  permission: 1,
  credits: "Maro X bot",
  description: "حذف الكنيات — مسح كنية عضو واحد أو جميع الأعضاء دفعة واحدة",
  prefix: true,
  category: "admin",
  usages: "clearnick | clearnick all | clearnick @mention",
  cooldowns: 5,
  premium: false,
  dependencies: {}
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID, mentions } = event;

  let threadInfo;
  try {
    threadInfo = await api.getThreadInfo(threadID);
  } catch (e) {
    return api.sendMessage("⚠️ تعذّر جلب معلومات المجموعة.", threadID, messageID);
  }

  const mentionedIDs = Object.keys(mentions || {});
  const sub = (args[0] || "").toLowerCase();

  // ─── حذف كنية شخص محدد عبر المنشن ──────────────────────────────────────
  if (mentionedIDs.length > 0) {
    let done = 0, failed = 0;
    for (const uid of mentionedIDs) {
      try {
        await api.changeNickname("", threadID, uid);
        done++;
      } catch (e) {
        failed++;
      }
    }
    return api.sendMessage(
      `🧹 حذف الكنيات\n${"━".repeat(25)}\n\n` +
      `✅ تم حذف الكنية لـ ${done} شخص` +
      (failed > 0 ? `\n⚠️ فشل لـ ${failed} شخص` : ""),
      threadID, messageID
    );
  }

  // ─── حذف جميع الكنيات ────────────────────────────────────────────────────
  if (sub === "all" || sub === "") {
    const participants = threadInfo.participantIDs || [];
    if (participants.length === 0)
      return api.sendMessage("⚠️ لا يوجد أعضاء في المجموعة.", threadID, messageID);

    const waitMsg = await new Promise(resolve =>
      api.sendMessage(
        `⏳ جاري مسح الكنيات لـ ${participants.length} عضو...`,
        threadID, (err, info) => resolve(info)
      )
    );

    let done = 0, failed = 0;
    for (const uid of participants) {
      try {
        await api.changeNickname("", threadID, uid);
        done++;
      } catch (e) {
        failed++;
      }
    }

    if (waitMsg?.messageID) {
      try { api.unsendMessage(waitMsg.messageID); } catch (_) {}
    }

    return api.sendMessage(
      `🧹 حذف الكنيات\n${"━".repeat(25)}\n\n` +
      `✅ تم مسح الكنيات بنجاح\n` +
      `👥 إجمالي الأعضاء : ${participants.length}\n` +
      `✔️ تم المسح        : ${done}\n` +
      (failed > 0 ? `❌ فشل المسح       : ${failed}\n` : "") +
      `${"━".repeat(25)}\n` +
      `💡 لمنع الكنيات مستقبلاً: -protect nickall clear`,
      threadID, messageID
    );
  }

  // ─── مساعدة ──────────────────────────────────────────────────────────────
  return api.sendMessage(
    `🧹 أمر حذف الكنيات\n${"━".repeat(25)}\n\n` +
    `الاستخدام:\n` +
    `-clearnick all       — مسح كنيات جميع الأعضاء\n` +
    `-clearnick @منشن     — مسح كنية شخص أو أكثر\n\n` +
    `💡 لحماية الكنيات ومنع إضافتها مستقبلاً:\n` +
    `-protect nickall clear`,
    threadID, messageID
  );
};
