const { performance } = require("perf_hooks");
const pidusage = require("pidusage");

module.exports.config = {
  name: "restart",
  version: "8.0.0",
  permission: 2,
  credits: "Maro X bot",
  prefix: true,
  premium: false,
  description: "إعادة تشغيل البوت مع تشخيص المشاكل التقنية",
  category: "admin",
  usages: "[check]",
  cooldowns: 10,
  dependencies: {
    "pidusage": ""
  }
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID } = event;

  const subCommand = args[0] ? args[0].toLowerCase() : "";

  // ── جمع البيانات التشخيصية ──────────────────────────────
  const timeStart = performance.now();

  let usage = null;
  try {
    usage = await pidusage(process.pid);
  } catch (_) {}

  const timeEnd = performance.now();
  const ping = Math.round(timeEnd - timeStart);

  const mem = process.memoryUsage();
  const heapUsedMB  = (mem.heapUsed  / 1024 / 1024).toFixed(1);
  const heapTotalMB = (mem.heapTotal / 1024 / 1024).toFixed(1);
  const rssMB       = (mem.rss       / 1024 / 1024).toFixed(1);
  const cpuPercent  = usage ? usage.cpu.toFixed(1) : "N/A";

  const uptimeSec = process.uptime();
  const h = Math.floor(uptimeSec / 3600);
  const m = Math.floor((uptimeSec % 3600) / 60);
  const s = Math.floor(uptimeSec % 60);
  const formattedUptime = `${h}h ${m}m ${s}s`;

  // ── تحديد أسباب المشاكل ─────────────────────────────────
  const issues = [];
  if (ping > 500)                       issues.push(`⚠️ تأخر عالي: ${ping}ms`);
  if (parseFloat(heapUsedMB) > 350)     issues.push(`⚠️ ذاكرة مرتفعة: ${heapUsedMB} MB`);
  if (parseFloat(cpuPercent) > 60)      issues.push(`⚠️ معالج مرتفع: ${cpuPercent}%`);

  // ── وضع الفحص فقط (check-) ──────────────────────────────
  if (subCommand === "check") {
    const statusIcon = issues.length > 0 ? "🔴" : "🟢";
    const statusText = issues.length > 0
      ? `تم اكتشاف ${issues.length} مشكلة:\n${issues.join("\n")}`
      : "البوت يعمل بشكل طبيعي ✅";

    const report =
      `╔══ 🤖 تشخيص البوت ══╗\n` +
      `${statusIcon} الحالة: ${statusText}\n` +
      `━━━━━━━━━━━━━━━━━━━\n` +
      `📶 Ping      : ${ping}ms\n` +
      `🧠 RAM       : ${heapUsedMB}/${heapTotalMB} MB\n` +
      `💾 RSS       : ${rssMB} MB\n` +
      `⚙️  CPU       : ${cpuPercent}%\n` +
      `⏱️  Uptime    : ${formattedUptime}\n` +
      `╚══════════════════╝\n\n` +
      (issues.length > 0
        ? `💡 يُنصح باستخدام -restart لإعادة التشغيل.`
        : `✅ لا حاجة لإعادة التشغيل الآن.`);

    return api.sendMessage(report, threadID, messageID);
  }

  // ── إعادة التشغيل الفعلية ───────────────────────────────
  const reason = issues.length > 0
    ? `تم اكتشاف المشاكل التالية:\n${issues.join("\n")}`
    : "طلب يدوي من المسؤول";

  const msg =
    `🔄 جارِ إعادة تشغيل البوت...\n` +
    `━━━━━━━━━━━━━━━━━━━\n` +
    `📋 السبب: ${reason}\n` +
    `━━━━━━━━━━━━━━━━━━━\n` +
    `📶 Ping   : ${ping}ms\n` +
    `🧠 RAM    : ${heapUsedMB}/${heapTotalMB} MB\n` +
    `⚙️  CPU    : ${cpuPercent}%\n` +
    `⏱️  Uptime : ${formattedUptime}\n` +
    `━━━━━━━━━━━━━━━━━━━\n` +
    `⏳ سيعود البوت خلال ثوانٍ...`;

  return api.sendMessage(msg, threadID, () => {
    setTimeout(() => process.exit(1), 1000);
  }, messageID);
};
