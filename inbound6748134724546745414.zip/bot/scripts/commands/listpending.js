module.exports.config = {
  name: "listpending",
  version: "1.0.0",
  permission: 2,
  credits: "Maro X bot",
  description: "عرض القروبات الموجودة في طلبات المراسلة",
  prefix: true,
  category: "admin",
  usages: "listpending",
  cooldowns: 5,
  dependencies: {}
};

module.exports.run = async function ({ api, event }) {
  const { threadID, messageID } = event;

  try {
    const other = await api.getThreadList(50, null, ["OTHER"]) || [];
    const pending = await api.getThreadList(50, null, ["PENDING"]) || [];

    const groups = [...other, ...pending].filter(t => t.isGroup);
    const inboxes = [...other, ...pending].filter(t => !t.isGroup);

    if (groups.length === 0 && inboxes.length === 0) {
      return api.sendMessage("✅ لا توجد طلبات مراسلة معلقة حالياً.", threadID, messageID);
    }

    let msg = `📋 طلبات المراسلة المعلقة\n${"─".repeat(30)}\n\n`;

    if (groups.length > 0) {
      msg += `👥 القروبات (${groups.length}):\n`;
      groups.forEach((t, i) => {
        const name = t.name || "قروب بدون اسم";
        const count = t.participantIDs ? t.participantIDs.length : "؟";
        msg += `${i + 1}. ${name}\n   🆔 ${t.threadID} | 👤 ${count} عضو\n`;
      });
    }

    if (inboxes.length > 0) {
      msg += `\n💬 رسائل فردية (${inboxes.length}):\n`;
      inboxes.forEach((t, i) => {
        const name = t.name || "مستخدم";
        msg += `${i + 1}. ${name}\n   🆔 ${t.threadID}\n`;
      });
    }

    msg += `\n${"─".repeat(30)}\n`;
    msg += `📌 المجموع: ${groups.length + inboxes.length} طلب\n`;
    msg += `💡 استخدم -autojoin now لقبولها جميعاً`;

    return api.sendMessage(msg, threadID, messageID);
  } catch (e) {
    return api.sendMessage("❌ حدث خطأ أثناء جلب القائمة:\n" + e.message, threadID, messageID);
  }
};
