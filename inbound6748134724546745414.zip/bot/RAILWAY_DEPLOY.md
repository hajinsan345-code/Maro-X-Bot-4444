# 🚂 نشر البوت على Railway

## الملفات الجاهزة
- `nixpacks.toml` — إعدادات البناء (Node 20 + python + cairo للـ canvas)
- `railway.json` — إعدادات النشر وإعادة التشغيل التلقائي
- `Procfile` — أمر التشغيل (worker)
- `package.json` — `engines.node >= 20`

## خطوات النشر

### 1) ارفع مجلد `bot/` إلى GitHub
```bash
cd bot
git init
git add .
git commit -m "IMRAN bot ready for Railway"
git branch -M main
git remote add origin https://github.com/<USERNAME>/<REPO>.git
git push -u origin main
```

### 2) أنشئ مشروع جديد على Railway
1. ادخل إلى https://railway.app
2. اضغط **New Project → Deploy from GitHub repo**
3. اختر المستودع الذي رفعت فيه مجلد `bot`

### 3) إعدادات Service مهمّة
- **Root Directory:** اتركه فارغاً (إذا رفعت مجلد `bot` كمستودع مستقل) أو اضبطه على `bot` (إذا رفعت كل المشروع).
- **Service Type:** غيّره إلى **Worker** (لأن البوت ليس Web Service) أو اتركه Web — Railway يقبل الاثنين.
- **Build Command:** يُكتشف تلقائياً من `nixpacks.toml`.
- **Start Command:** `node main/catalogs/IMRANA.js` (مكتوب في `railway.json`).

### 4) متغيّرات البيئة (Variables)
أضف في تبويب **Variables**:
| المفتاح | القيمة |
|---|---|
| `YOUTUBE_DL_SKIP_PYTHON_CHECK` | `1` |
| `NODE_OPTIONS` | `--max-old-space-size=1024` |
| `PORT` | `3000` (أو اتركها — Railway يضبطها تلقائياً) |

### 5) ⚠️ ملف `appstate.json` (مهم جدّاً)
هذا الملف يحتوي جلسة فيسبوك. أمامك خياران:

**أ) ارفعه مع الكود (أبسط لكن أقل أماناً):**
الملف موجود بالفعل في `bot/appstate.json` — لكن انتبه: لا تجعل المستودع عاماً (public)، اجعله **Private**.

**ب) عبر متغيّر بيئة (أأمن):**
1. حوّل محتوى `appstate.json` إلى Base64:
   ```bash
   base64 -w 0 appstate.json
   ```
2. أضف متغيّر `APPSTATE_B64` في Railway بالقيمة الناتجة.
3. عدّل `bot/autoLogin.js` ليفك التشفير عند الإقلاع. (أخبرني وسأكتبه لك.)

### 6) شغّل النشر
- اضغط **Deploy** — البناء يستغرق 2–5 دقائق (تنزيل cairo وتجميع canvas).
- راقب اللوقات من تبويب **Deployments → View Logs**.

## ⚠️ تحذير حسّاس بخصوص فيسبوك
- البوت اليوم يفشل في الدخول لأن فيسبوك يحظر تسجيل الدخول من IP الـ Replit.
- **Railway قد يواجه نفس المشكلة** — IP الخاصّ بسيرفراتها معروف لفيسبوك أيضاً.
- إذا فشل الدخول من Railway:
  1. سجّل دخول إلى الحساب من المتصفح وأكّد إشعار "Was this you?".
  2. ولّد ملف `appstate.json` جديد من نفس المتصفح بعد التأكيد.
  3. ارفعه مباشرةً قبل أن تنتهي صلاحية الجلسة.
- للحلّ الأكثر استقراراً: استعمل خدمة **Residential Proxy** (مثل BrightData) واضبطها في `FCA_OPTION.proxy` داخل `Config.json`.

## أوامر مفيدة بعد النشر
- إعادة تشغيل: من لوحة Railway → **Restart**.
- فحص الحالة: افتح الـ URL العام (مثلاً `https://your-app.up.railway.app/stats`).
- الـ endpoints المتاحة: `/`, `/ping`, `/health`, `/stats`.
