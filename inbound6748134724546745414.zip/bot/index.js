'use strict';

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 1️⃣ ANTI-CRASH
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
process.on('uncaughtException', (err) => {
  console.error('[AntiCrash] ⚠️ خطأ غير متوقع:', err.message);
});

process.on('unhandledRejection', (reason) => {
  console.error('[AntiCrash] ⚠️ Promise مرفوض:', reason);
});

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 2️⃣ KEEP-ALIVE SERVER
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
const http = require('http');
http.createServer((req, res) => {
  res.writeHead(200);
  res.end('🤖 IMRAN Bot is Running!');
}).listen(3000, () => {
  console.log('[KeepAlive] 🟢 Server يعمل على port 3000');
});

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 3️⃣ مراقبة الرام
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
setInterval(() => {
  const usedMB = Math.round(process.memoryUsage().heapUsed / 1024 / 1024);
  if (usedMB > 400) {
    console.log(`[RAM] 🔴 رام عالي: ${usedMB}MB - إعادة تشغيل...`);
    process.exit(1);
  } else {
    console.log(`[RAM] 🟢 الرام: ${usedMB}MB`);
  }
}, 5 * 60 * 1000);

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 4️⃣ تشغيل البوت
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
const { checkAndLogin } = require('./autoLogin');
checkAndLogin((api) => {
  require('./main/catalogs/IMRANA.js');
});
