const fs = require('fs');
const path = require('path');
const login = require('fca-unofficial');

const appstatePath = path.join(__dirname, 'appstate.json');

function checkAndLogin(callback) {
  if (!fs.existsSync(appstatePath)) {
    console.log('[AutoLogin] ❌ ملف appstate.json غير موجود!');
    return;
  }

  let appstate;
  try {
    appstate = JSON.parse(fs.readFileSync(appstatePath, 'utf8'));
  } catch (e) {
    console.log('[AutoLogin] ❌ خطأ في قراءة appstate:', e.message);
    return;
  }

  login({
    appState: appstate,

    // ✅ إعدادات الحماية من الحظر
    online: false,
    autoMarkRead: false,
    autoMarkDelivery: false,
    listenEvents: true,
    selfListen: false,
    logLevel: 'silent',
    forceLogin: false,

    // ✅ محاكاة متصفح حقيقي
    userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'

  }, (err, api) => {
    if (err) {
      console.log('[AutoLogin] ❌ فشل تسجيل الدخول:', err.message || err);
      return;
    }

    // ✅ إعدادات API بعد الدخول
    api.setOptions({
      listenEvents: true,
      selfListen: false,
      autoMarkRead: false,
      autoMarkDelivery: false,
      online: false,
      logLevel: 'silent'
    });

    console.log('[AutoLogin] ✅ تم تسجيل الدخول بنجاح!');

    // ✅ حفظ الكوكيز تلقائياً كل 30 دقيقة
    setInterval(() => {
      try {
        fs.writeFileSync(appstatePath, JSON.stringify(api.getAppState()));
        console.log('[AutoLogin] 💾 تم حفظ الكوكيز بنجاح');
      } catch (e) {
        console.log('[AutoLogin] ⚠️ فشل حفظ الكوكيز:', e.message);
      }
    }, 30 * 60 * 1000);

    callback(api);
  });
}

module.exports = { checkAndLogin };
