const originalExit = process.exit.bind(process);
process.exit = function(code) {
  if (code !== 0) {
    originalExit(code);
  }
};

process.on('uncaughtException', function(err) {
  if (err && err.message) {
    process.stderr.write(`[error] uncaught exception: ${err.message}\n`);
    if (err.stack) process.stderr.write(err.stack + '\n');
  }
});

process.on('unhandledRejection', function(reason, promise) {
  const msg = (reason && reason.message) ? reason.message : String(reason);
  process.stderr.write(`[error] unhandled rejection: ${msg}\n`);
});

setInterval(() => {}, 60 * 60 * 1000);

require('./IMRANB.js');
