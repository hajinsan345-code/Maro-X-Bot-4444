console.clear();
const { spawn } = require("child_process");
const express = require("express");
const app = express();
const chalk = require('chalk');
const logger = require("./IMRANC.js");
const path = require('path');
const http = require('http');
const os = require('os');
const fs = require('fs');

const PORT = process.env.PORT || 3000;
const CRASH_LOG = path.join(__dirname, '../../..', 'crash.log');

// ─── إعدادات الصيانة التلقائية ───────────────────────────────────────────────
const MAINTENANCE = {
  memory: {
    maxHeapMB: 900,
    softHeapMB: 700,
    checkInterval: 2 * 60 * 1000
  },
  ping: {
    timeoutMs: 12000,
    maxFailures: 5,
    checkInterval: 3 * 60 * 1000
  },
  errors: {
    maxPerWindow: 30,
    windowMs: 5 * 60 * 1000
  },
  stale: {
    maxSilenceMs: 25 * 60 * 1000
  },
  cleanup: {
    cacheInterval: 60 * 60 * 1000,
    crashLogMaxBytes: 2 * 1024 * 1024
  },
  gc: {
    interval: 10 * 60 * 1000
  }
};

// ─── تحسين عميل HTTP العالمي (keep-alive لجميع الطلبات) ─────────────────────
try {
  const https = require('https');
  const httpAgent = new http.Agent({ keepAlive: true, keepAliveMsecs: 30000, maxSockets: 50 });
  const httpsAgent = new https.Agent({ keepAlive: true, keepAliveMsecs: 30000, maxSockets: 50 });
  http.globalAgent = httpAgent;
  https.globalAgent = httpsAgent;
} catch (e) {}

// ─── حالة الصيانة ──────────────────────────────────────────────────────────────
const health = {
  pingFailures: 0,
  errorTimestamps: [],
  lastActivityAt: Date.now(),
  restartCount: 0,
  startedAt: Date.now(),
  childPid: null,
  childRef: null,
  lastCrashReason: null,
  lastCrashTime: null
};

global.countRestart = 0;
global.lastRestartTime = Date.now();

// ─── كتابة سجل الانهيار ───────────────────────────────────────────────────────
function writeCrashLog(reason, exitCode, aliveFor, stderrLines) {
  try {
    const entry = [
      `\n${'─'.repeat(60)}`,
      `[${new Date().toISOString()}] CRASH #${health.restartCount + 1}`,
      `  السبب    : ${reason}`,
      `  كود الخروج: ${exitCode}`,
      `  عاش لـ   : ${aliveFor}s`,
      `  إعادات   : ${global.countRestart}`,
      stderrLines ? `  stderr   :\n${stderrLines.map(l => '    ' + l).join('\n')}` : ''
    ].filter(Boolean).join('\n');

    fs.appendFileSync(CRASH_LOG, entry + '\n');
  } catch (e) {}
}

// ─── خادم الويب ───────────────────────────────────────────────────────────────
app.get('/', function(req, res) {
  res.sendFile(path.join(__dirname, '/website/ryuko.html'));
});

app.get('/ping', function(req, res) {
  health.lastActivityAt = Date.now();
  res.status(200).json({
    status: 'alive',
    uptime: process.uptime(),
    time: new Date().toISOString()
  });
});

app.get('/health', function(req, res) {
  const mem = process.memoryUsage();
  const uptime = Math.floor((Date.now() - health.startedAt) / 1000);
  const childAlive = health.childRef && !health.childRef.killed;

  res.status(200).json({
    status: childAlive ? 'healthy' : 'degraded',
    uptime_seconds: uptime,
    restart_count: health.restartCount,
    ping_failures: health.pingFailures,
    child_alive: childAlive,
    child_pid: health.childPid,
    last_crash: health.lastCrashReason
      ? { reason: health.lastCrashReason, time: health.lastCrashTime }
      : null,
    memory: {
      heapUsedMB: Math.round(mem.heapUsed / 1024 / 1024),
      heapTotalMB: Math.round(mem.heapTotal / 1024 / 1024),
      rssMB: Math.round(mem.rss / 1024 / 1024)
    },
    system: {
      freeMB: Math.round(os.freemem() / 1024 / 1024),
      totalMB: Math.round(os.totalmem() / 1024 / 1024),
      loadAvg: os.loadavg()
    },
    last_activity: new Date(health.lastActivityAt).toISOString()
  });
});

app.get('/crashes', function(req, res) {
  try {
    if (fs.existsSync(CRASH_LOG)) {
      const content = fs.readFileSync(CRASH_LOG, 'utf8');
      const lines = content.split('\n').slice(-100);
      res.setHeader('Content-Type', 'text/plain; charset=utf-8');
      res.send(lines.join('\n'));
    } else {
      res.json({ message: 'لا يوجد سجل انهيارات' });
    }
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

const server = app.listen(PORT, () => {
  logger.loader(`app deployed on port ${chalk.blueBright(PORT)}`);
});

server.keepAliveTimeout = 120000;
server.headersTimeout = 120000;

// ─── معالجة الأخطاء ───────────────────────────────────────────────────────────
process.on('uncaughtException', function(err) {
  logger(`uncaught exception in main process: ${err.message}`, "error");
  recordError();
});

process.on('unhandledRejection', function(reason) {
  logger(`unhandled rejection in main process: ${reason}`, "error");
  recordError();
});

// ─── تسجيل الأخطاء وفحص الحد الأقصى ─────────────────────────────────────────
function recordError() {
  const now = Date.now();
  health.errorTimestamps.push(now);
  health.errorTimestamps = health.errorTimestamps.filter(
    t => now - t < MAINTENANCE.errors.windowMs
  );

  if (health.errorTimestamps.length >= MAINTENANCE.errors.maxPerWindow) {
    logger(
      `[صيانة] تجاوز عدد الأخطاء ${MAINTENANCE.errors.maxPerWindow} خلال 5 دقائق — إعادة التشغيل`,
      "warn"
    );
    health.errorTimestamps = [];
    forceRestartChild("error_rate_exceeded");
  }
}

// ─── تأخير إعادة التشغيل ──────────────────────────────────────────────────────
function getRestartDelay(count) {
  if (count <= 1) return 2000;
  if (count <= 3) return 8000;
  if (count <= 6) return 15000;
  if (count <= 10) return 30000;
  return 60000;
}

// ─── إعادة تشغيل قسرية للعملية الفرعية ──────────────────────────────────────
function forceRestartChild(reason) {
  health.lastCrashReason = reason;
  health.lastCrashTime = new Date().toISOString();

  if (health.childRef && !health.childRef.killed) {
    logger(`[صيانة] إنهاء العملية الفرعية (السبب: ${reason})`, "warn");
    try {
      health.childRef.kill('SIGTERM');
      setTimeout(() => {
        if (health.childRef && !health.childRef.killed) {
          health.childRef.kill('SIGKILL');
        }
      }, 5000);
    } catch (e) {}
  }
}

// ─── تشغيل البوت ──────────────────────────────────────────────────────────────
function startBot(message) {
  if (message) logger(message, "starting");
  console.log(chalk.blue('DEPLOYING MAIN SYSTEM'));

  const delay = getRestartDelay(global.countRestart);
  if (global.countRestart > 0) {
    logger(`restarting bot in ${delay / 1000}s... (attempt #${global.countRestart})`, "warn");
  }

  setTimeout(() => {
    // التقاط stderr بشكل منفصل لتسجيل سبب الانهيار
    const child = spawn(
      "node",
      [
        "--trace-warnings",
        "--async-stack-traces",
        "--max-old-space-size=1024",
        "--max-semi-space-size=128",
        "--expose-gc",
        "--no-deprecation",
        "IMRANB_patched.js"
      ],
      {
        cwd: __dirname,
        stdio: ['inherit', 'inherit', 'pipe'],
        shell: false,
        detached: true,
        env: { ...process.env, NODE_OPTIONS: '--max-old-space-size=1024' }
      }
    );

    health.childRef = child;
    health.childPid = child.pid;
    health.lastActivityAt = Date.now();
    health.pingFailures = 0;

    const startedAt = Date.now();
    const stderrBuffer = [];

    // التقاط أخطاء العملية الفرعية
    if (child.stderr) {
      child.stderr.setEncoding('utf8');
      child.stderr.on('data', (data) => {
        const lines = data.trim().split('\n').filter(Boolean);
        lines.forEach(line => {
          if (!line.includes('DeprecationWarning') && !line.includes('ExperimentalWarning')) {
            process.stderr.write('[BOT] ' + line + '\n');
            stderrBuffer.push(line);
            if (stderrBuffer.length > 50) stderrBuffer.shift();
          }
        });
      });
    }

    child.on("close", (codeExit) => {
      const aliveFor = Math.floor((Date.now() - startedAt) / 1000);
      const reason = codeExit === 0 ? 'normal_exit'
        : codeExit === null ? 'killed_by_signal'
        : codeExit === 1 ? 'runtime_error'
        : `exit_code_${codeExit}`;

      logger(`bot process ended (code: ${codeExit} / ${reason}) after ${aliveFor}s`, "warn");

      // تسجيل الانهيار في ملف
      if (codeExit !== 0) {
        writeCrashLog(reason, codeExit, aliveFor, stderrBuffer.slice(-10));
      }

      health.childRef = null;
      health.childPid = null;
      health.restartCount++;
      health.lastCrashReason = reason;
      health.lastCrashTime = new Date().toISOString();

      // إعادة ضبط عداد الإعادة إذا عاش البوت مدة كافية
      if (aliveFor > 600) {
        global.countRestart = 0;
      } else if (aliveFor > 120) {
        global.countRestart = Math.max(0, global.countRestart - 1);
      } else {
        global.countRestart += 1;
      }

      startBot();
    });

    child.on("error", function(error) {
      logger("child process error: " + JSON.stringify(error), "error");
      recordError();
    });
  }, global.countRestart > 0 ? delay : 0);
}

// ─── فحص الـ Ping وإعادة التشغيل عند التباطؤ ─────────────────────────────────
function selfPing() {
  // إذا كانت العملية الفرعية ميتة بالفعل، لا حاجة للـ ping
  if (!health.childRef || health.childRef.killed) {
    return;
  }

  const startTime = Date.now();

  const options = {
    host: 'localhost',
    port: PORT,
    path: '/ping',
    method: 'GET',
    timeout: MAINTENANCE.ping.timeoutMs
  };

  const req = http.request(options, (res) => {
    const responseTime = Date.now() - startTime;
    health.lastActivityAt = Date.now();
    health.pingFailures = 0;

    if (responseTime > 6000) {
      logger(`[صيانة] استجابة بطيئة: ${responseTime}ms`, "warn");
    }
  });

  req.on('timeout', () => {
    req.destroy();
    health.pingFailures++;

    if (health.pingFailures >= MAINTENANCE.ping.maxFailures) {
      logger('[صيانة] البوت لا يستجيب — إعادة التشغيل التلقائية', "warn");
      health.pingFailures = 0;
      forceRestartChild("ping_timeout");
    } else {
      logger(`[صيانة] مهلة ping (${health.pingFailures}/${MAINTENANCE.ping.maxFailures})`, "warn");
    }
  });

  req.on('error', () => {
    health.pingFailures++;
  });

  req.end();
}

// ─── مراقبة الذاكرة ───────────────────────────────────────────────────────────
function checkMemory() {
  const mem = process.memoryUsage();
  const heapMB = Math.round(mem.heapUsed / 1024 / 1024);
  const rssMB = Math.round(mem.rss / 1024 / 1024);

  if (heapMB > MAINTENANCE.memory.maxHeapMB) {
    logger(
      `[صيانة] ذاكرة مرتفعة: ${heapMB}MB heap / ${rssMB}MB RSS — محاولة تحرير`,
      "warn"
    );

    if (global.gc) {
      try { global.gc(); } catch(e) {}
    }

    setTimeout(() => {
      const memAfter = process.memoryUsage();
      const heapAfter = Math.round(memAfter.heapUsed / 1024 / 1024);
      if (heapAfter > MAINTENANCE.memory.maxHeapMB) {
        logger(`[صيانة] فشل تحرير الذاكرة (${heapAfter}MB) — إعادة التشغيل`, "warn");
        forceRestartChild("memory_exceeded");
      } else {
        logger(`[صيانة] تم تحرير الذاكرة: ${heapAfter}MB`, "warn");
      }
    }, 8000);
  }
}

// ─── مراقبة الصمود (Stale detection) ─────────────────────────────────────────
function checkStale() {
  // لا تُعيد التشغيل إذا كانت العملية الفرعية ميتة (ستُعاد تلقائياً)
  const childAlive = health.childRef && !health.childRef.killed;
  if (!childAlive) return;

  const silence = Date.now() - health.lastActivityAt;
  if (silence > MAINTENANCE.stale.maxSilenceMs) {
    logger(
      `[صيانة] لا نشاط منذ ${Math.round(silence / 60000)} دقيقة — إعادة التشغيل`,
      "warn"
    );
    health.lastActivityAt = Date.now();
    forceRestartChild("stale_process");
  }
}

// ─── تنظيف ذاكرة الدرع (Shield duplicates cleanup) ───────────────────────────
function cleanShieldMemory() {
  try {
    if (global.shield && global.shield.duplicates) {
      const now = Date.now();
      const win = (global.shield.limits && global.shield.limits.duplicateWindow) || 60000;
      let cleaned = 0;
      for (const [key, val] of global.shield.duplicates) {
        if (now - val.first > win * 2) {
          global.shield.duplicates.delete(key);
          cleaned++;
        }
      }
      if (cleaned > 0) {
        logger(`[صيانة] تنظيف ذاكرة الدرع: حُذف ${cleaned} سجل`, "info");
      }
    }
  } catch (e) {}

  if (global.gc) {
    try { global.gc(); } catch(e) {}
  }
}

// ─── تنظيف ملفات الكاش القديمة ────────────────────────────────────────────────
function cleanCacheFiles() {
  // تنظيف فقط مجلدات الكاش الحقيقية + ملفات status_ المؤقتة في botdata
  const cacheDirs = [
    path.join(__dirname, '../../scripts/commands/cache'),
    path.join(__dirname, '../../scripts/events/cache')
  ];

  // ملفات يجب الحفاظ عليها (قواعد البيانات والإعدادات)
  const PROTECTED_NAMES = new Set([
    'maindata.sqlite', 'approvedlists.json', 'premiumlists.json',
    'appstate.json', 'config.json'
  ]);

  let totalCleaned = 0;
  const now = Date.now();
  const MAX_AGE = 30 * 60 * 1000;

  for (const dir of cacheDirs) {
    try {
      if (!fs.existsSync(dir)) continue;
      const files = fs.readdirSync(dir);
      for (const f of files) {
        if (PROTECTED_NAMES.has(f) || f.startsWith('.')) continue;
        try {
          const fp = path.join(dir, f);
          const stat = fs.statSync(fp);
          if (stat.isFile() && (now - stat.mtimeMs) > MAX_AGE) {
            fs.unlinkSync(fp);
            totalCleaned++;
          }
        } catch (e) {}
      }
    } catch (e) {}
  }

  // تنظيف ملفات status_ المؤقتة فقط في botdata
  try {
    const botdataDir = path.join(__dirname, '../botdata');
    if (fs.existsSync(botdataDir)) {
      const files = fs.readdirSync(botdataDir);
      for (const f of files) {
        if (!f.startsWith('status_') || !f.endsWith('.png')) continue;
        try {
          const fp = path.join(botdataDir, f);
          const stat = fs.statSync(fp);
          if ((now - stat.mtimeMs) > 5 * 60 * 1000) {
            fs.unlinkSync(fp);
            totalCleaned++;
          }
        } catch (e) {}
      }
    }
  } catch (e) {}

  if (totalCleaned > 0) {
    logger(`[صيانة] تنظيف الكاش: حُذف ${totalCleaned} ملف قديم`, "info");
  }
}

// ─── تدوير سجل الانهيارات ────────────────────────────────────────────────────
function rotateCrashLog() {
  try {
    if (!fs.existsSync(CRASH_LOG)) return;
    const stat = fs.statSync(CRASH_LOG);
    if (stat.size > MAINTENANCE.cleanup.crashLogMaxBytes) {
      const content = fs.readFileSync(CRASH_LOG, 'utf8');
      const half = content.slice(Math.floor(content.length / 2));
      fs.writeFileSync(CRASH_LOG, '... [تم تدوير السجل] ...\n' + half);
      logger('[صيانة] تم تدوير سجل الانهيارات', 'info');
    }
  } catch (e) {}
}

// ─── تشغيل GC الدوري لتقليل ضغط الذاكرة ─────────────────────────────────────
function periodicGC() {
  if (global.gc) {
    try {
      const before = Math.round(process.memoryUsage().heapUsed / 1024 / 1024);
      global.gc();
      const after = Math.round(process.memoryUsage().heapUsed / 1024 / 1024);
      if (before - after > 20) {
        logger(`[صيانة] GC دوري: ${before}MB → ${after}MB`, 'info');
      }
    } catch (e) {}
  }
}

// ─── إحصائيات شاملة (endpoint جديد) ─────────────────────────────────────────
app.get('/stats', function(req, res) {
  const mem = process.memoryUsage();
  const uptime = Math.floor((Date.now() - health.startedAt) / 1000);
  const childAlive = health.childRef && !health.childRef.killed;
  const cpus = os.cpus();

  res.status(200).json({
    bot: {
      name: 'Maro X bot',
      status: childAlive ? 'online' : 'offline',
      uptime_seconds: uptime,
      uptime_human: `${Math.floor(uptime/3600)}h ${Math.floor((uptime%3600)/60)}m`,
      restart_count: health.restartCount,
      child_pid: health.childPid
    },
    memory: {
      heap_used_mb: Math.round(mem.heapUsed / 1024 / 1024),
      heap_total_mb: Math.round(mem.heapTotal / 1024 / 1024),
      rss_mb: Math.round(mem.rss / 1024 / 1024),
      external_mb: Math.round(mem.external / 1024 / 1024)
    },
    server: {
      platform: `${process.platform} ${process.arch}`,
      node: process.version,
      cpu_model: cpus[0]?.model || 'unknown',
      cpu_cores: cpus.length,
      total_ram_mb: Math.round(os.totalmem() / 1024 / 1024),
      free_ram_mb: Math.round(os.freemem() / 1024 / 1024),
      load_avg: os.loadavg().map(l => l.toFixed(2))
    },
    health: {
      ping_failures: health.pingFailures,
      error_count: health.errorTimestamps.length,
      last_activity: new Date(health.lastActivityAt).toISOString(),
      last_crash: health.lastCrashReason
    }
  });
});

// ─── جداول الصيانة ────────────────────────────────────────────────────────────
setInterval(selfPing,          MAINTENANCE.ping.checkInterval);
setInterval(checkMemory,       MAINTENANCE.memory.checkInterval);
setInterval(checkStale,        MAINTENANCE.stale.maxSilenceMs / 2);
setInterval(cleanShieldMemory, 15 * 60 * 1000);
setInterval(cleanCacheFiles,   MAINTENANCE.cleanup.cacheInterval);
setInterval(rotateCrashLog,    30 * 60 * 1000);
setInterval(periodicGC,        MAINTENANCE.gc.interval);

// تنظيف أولي بعد دقيقتين من البدء
setTimeout(cleanCacheFiles, 2 * 60 * 1000);

// ─── إيقاف نظيف عند إشارات الإنهاء (يمنع تشغيل نسختين) ───────────────────────
let _shuttingDown = false;
function shutdown(signal) {
  if (_shuttingDown) return;
  _shuttingDown = true;
  logger(`received ${signal} — shutting down child and exiting`, "warn");
  try {
    if (health.childRef && !health.childRef.killed) {
      try { process.kill(-health.childRef.pid, 'SIGKILL'); } catch (e) {}
      try { health.childRef.kill('SIGKILL'); } catch (e) {}
    }
  } catch (e) {}
  setTimeout(() => process.exit(0), 500);
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT',  () => shutdown('SIGINT'));
process.on('SIGHUP',  () => shutdown('SIGHUP'));

// ─── تشغيل البوت ──────────────────────────────────────────────────────────────
startBot();
