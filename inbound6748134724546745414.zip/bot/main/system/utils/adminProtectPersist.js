const fs   = require("fs");
const path = require("path");

const FILE = path.join(__dirname, "../../../data/adminProtect.json");

function load() {
  try {
    const raw = fs.readFileSync(FILE, "utf8");
    const obj = JSON.parse(raw);
    if (!global.adminProtectData) global.adminProtectData = new Map();
    for (const [tid, val] of Object.entries(obj)) {
      if (!global.adminProtectData.has(tid)) {
        global.adminProtectData.set(tid, val);
      }
    }
  } catch (_) {}
}

function save() {
  try {
    if (!global.adminProtectData) return;
    const obj = {};
    for (const [tid, val] of global.adminProtectData.entries()) {
      obj[tid] = val;
    }
    fs.writeFileSync(FILE, JSON.stringify(obj, null, 2), "utf8");
  } catch (_) {}
}

module.exports = { load, save };
