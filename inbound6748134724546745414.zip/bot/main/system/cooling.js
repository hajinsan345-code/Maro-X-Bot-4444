/**
 * نظام التبريد (Cooling System)
 * يحمي البوت من الإفراط في الحمل عبر:
 *  - تحديد عدد الأوامر لكل مستخدم/مجموعة/النظام كله في نافذة زمنية
 *  - تحديد عدد الأوامر المتزامنة قيد التنفيذ
 *  - مراقبة استهلاك الذاكرة وإيقاف الأوامر مؤقتاً عند الضغط
 *  - السماح للمالكين/المشغلين بتجاوز كل القيود
 */

const LIMITS = {
  perUser:    { max: 6,  windowMs: 10_000 },
  perThread:  { max: 12, windowMs: 10_000 },
  global:     { max: 60, windowMs: 10_000 },
  concurrency: 8,
  memorySoftMB: 700,
  memoryHardMB: 850,
  cooldownAfterCoolingMs: 30_000,
};

const userHits   = new Map();   // senderID -> [timestamps]
const threadHits = new Map();   // threadID -> [timestamps]
let   globalHits = [];          // [timestamps]
let   running    = 0;
const recentCool = new Map();   // key -> until-timestamp

const stats = {
  total: 0,
  throttled: 0,
  concurrencyRejects: 0,
  memoryRejects: 0,
  startedAt: Date.now(),
  lastReason: null,
};

function prune(arr, windowMs, now) {
  const cutoff = now - windowMs;
  while (arr.length && arr[0] < cutoff) arr.shift();
}

function recordHit(map, key, now, windowMs) {
  let arr = map.get(key);
  if (!arr) { arr = []; map.set(key, arr); }
  prune(arr, windowMs, now);
  arr.push(now);
  return arr.length;
}

function memMB() {
  return Math.round(process.memoryUsage().heapUsed / 1024 / 1024);
}

function isCooling(key, now) {
  const until = recentCool.get(key);
  if (!until) return false;
  if (now >= until) { recentCool.delete(key); return false; }
  return true;
}

function trip(key, now) {
  recentCool.set(key, now + LIMITS.cooldownAfterCoolingMs);
}

/**
 * يفحص ما إذا كان مسموحاً بتنفيذ الأمر.
 * @returns {{allow: boolean, reason?: string, retryAfterSec?: number}}
 */
function check({ senderID, threadID, command, isPrivileged }) {
  const now = Date.now();
  stats.total++;

  // المالكون/المشغلون يتجاوزون كل القيود
  if (isPrivileged) return { allow: true };

  // ضغط الذاكرة
  const used = memMB();
  if (used >= LIMITS.memoryHardMB) {
    stats.memoryRejects++;
    stats.throttled++;
    stats.lastReason = `memory_hard(${used}MB)`;
    return { allow: false, reason: 'memory', retryAfterSec: 30 };
  }
  if (used >= LIMITS.memorySoftMB && command?.config?.cooldowns >= 30) {
    // الأوامر الثقيلة فقط تُحجب عند الضغط الناعم
    stats.memoryRejects++;
    stats.throttled++;
    stats.lastReason = `memory_soft(${used}MB)`;
    return { allow: false, reason: 'memory', retryAfterSec: 15 };
  }

  // التزامن
  if (running >= LIMITS.concurrency) {
    stats.concurrencyRejects++;
    stats.throttled++;
    stats.lastReason = 'concurrency';
    return { allow: false, reason: 'busy', retryAfterSec: 5 };
  }

  // التبريد المعلّق على هذا المفتاح
  if (isCooling(`u:${senderID}`, now) || isCooling(`t:${threadID}`, now)) {
    stats.throttled++;
    stats.lastReason = 'cooling';
    return { allow: false, reason: 'cooling', retryAfterSec: 10 };
  }

  // النوافذ الترددية
  prune(globalHits, LIMITS.global.windowMs, now);
  if (globalHits.length >= LIMITS.global.max) {
    stats.throttled++;
    stats.lastReason = 'global_rate';
    return { allow: false, reason: 'global_rate', retryAfterSec: 10 };
  }

  const u = recordHit(userHits, senderID, now, LIMITS.perUser.windowMs);
  if (u > LIMITS.perUser.max) {
    trip(`u:${senderID}`, now);
    stats.throttled++;
    stats.lastReason = 'user_rate';
    return { allow: false, reason: 'user_rate', retryAfterSec: Math.ceil(LIMITS.cooldownAfterCoolingMs / 1000) };
  }

  const t = recordHit(threadHits, threadID, now, LIMITS.perThread.windowMs);
  if (t > LIMITS.perThread.max) {
    trip(`t:${threadID}`, now);
    stats.throttled++;
    stats.lastReason = 'thread_rate';
    return { allow: false, reason: 'thread_rate', retryAfterSec: Math.ceil(LIMITS.cooldownAfterCoolingMs / 1000) };
  }

  globalHits.push(now);
  return { allow: true };
}

function start() { running++; }
function end()   { if (running > 0) running--; }

function getStats() {
  return {
    ...stats,
    running,
    memoryMB: memMB(),
    activeUsers: userHits.size,
    activeThreads: threadHits.size,
    coolingKeys: recentCool.size,
    uptimeSec: Math.floor((Date.now() - stats.startedAt) / 1000),
    limits: LIMITS,
  };
}

// تنظيف دوري للخرائط الفارغة (كل 5 دقائق)
setInterval(() => {
  const now = Date.now();
  for (const [k, arr] of userHits) {
    prune(arr, LIMITS.perUser.windowMs, now);
    if (arr.length === 0) userHits.delete(k);
  }
  for (const [k, arr] of threadHits) {
    prune(arr, LIMITS.perThread.windowMs, now);
    if (arr.length === 0) threadHits.delete(k);
  }
  for (const [k, until] of recentCool) {
    if (now >= until) recentCool.delete(k);
  }
  prune(globalHits, LIMITS.global.windowMs, now);
}, 5 * 60 * 1000).unref?.();

module.exports = { check, start, end, getStats, LIMITS };
