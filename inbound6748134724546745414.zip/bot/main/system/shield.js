/**
 * IMRAN BOT - Anti-Ban Shield System
 * نظام الدرع لمكافحة الحظر
 * 
 * الطبقات:
 *   1. Rate Limiter   — تحديد معدل الرسائل
 *   2. Duplicate Guard — منع تكرار المحتوى
 *   3. Error Watcher  — مراقبة أخطاء فيسبوك
 *   4. Sleep Mode     — وضع السكون عند الخطر
 */

const logger = require("../catalogs/IMRANC.js");

// ────────────────────────────────────────────────────────────────
// الحالة العامة للنظام
// ────────────────────────────────────────────────────────────────
if (!global.shield) {
  global.shield = {
    enabled: true,

    // إحصائيات الرسائل الصادرة
    stats: {
      sentThisMinute: 0,
      sentThisHour: 0,
      totalSent: 0,
      windowStart: Date.now(),
      hourStart: Date.now()
    },

    // الحدود القصوى (قابلة للتعديل)
    limits: {
      maxPerMinute: 25,       // حد الرسائل في الدقيقة
      maxPerHour: 250,        // حد الرسائل في الساعة
      duplicateWindow: 60000, // نافذة تكرار المحتوى (ms) = دقيقة
      duplicateMaxCount: 20,  // أقصى تكرار لنفس النص (يسمح للرسائل التلقائية)
      errorThreshold: 8,      // عدد الأخطاء قبل وضع السكون (زيادة لتقليل الحساسية)
      sleepDuration: 180000   // مدة السكون = 3 دقائق (بدلاً من 5)
    },

    // تتبع المحتوى المكرر
    duplicates: new Map(),

    // مراقبة الأخطاء
    errors: {
      count: 0,
      history: [],           // آخر 20 خطأ
      lastReset: Date.now()
    },

    // وضع السكون
    sleep: {
      active: false,
      until: 0,
      reason: ""
    },

    // مستوى الخطر: low / medium / high / critical
    riskLevel: "low",

    // سجل الأحداث للمراجعة
    log: []
  };
}

// ────────────────────────────────────────────────────────────────
// حساب مستوى الخطر
// ────────────────────────────────────────────────────────────────
function calculateRisk() {
  const s = global.shield;
  const errRate = s.errors.count;
  const msgRate = s.stats.sentThisMinute;

  if (s.sleep.active || errRate >= s.limits.errorThreshold) return "critical";
  if (errRate >= 3 || msgRate >= s.limits.maxPerMinute * 0.8) return "high";
  if (errRate >= 1 || msgRate >= s.limits.maxPerMinute * 0.5) return "medium";
  return "low";
}

// ────────────────────────────────────────────────────────────────
// إضافة حدث للسجل
// ────────────────────────────────────────────────────────────────
function addLog(type, detail) {
  const entry = { time: new Date().toISOString(), type, detail };
  global.shield.log.unshift(entry);
  if (global.shield.log.length > 50) global.shield.log.pop();
  logger(`[shield] ${type}: ${detail}`, "shield");
}

// ────────────────────────────────────────────────────────────────
// إعادة ضبط نوافذ الوقت
// ────────────────────────────────────────────────────────────────
function resetWindows() {
  const now = Date.now();
  const s = global.shield.stats;

  if (now - s.windowStart >= 60000) {
    s.sentThisMinute = 0;
    s.windowStart = now;
  }
  if (now - s.hourStart >= 3600000) {
    s.sentThisHour = 0;
    s.hourStart = now;
    global.shield.errors.count = 0;
    global.shield.errors.lastReset = now;
  }
}

// ────────────────────────────────────────────────────────────────
// التحقق من تكرار المحتوى
// ────────────────────────────────────────────────────────────────
function checkDuplicate(text) {
  if (!text || typeof text !== "string") return false;
  const key = text.trim().substring(0, 80);
  const now = Date.now();
  const dup = global.shield.duplicates;
  const win = global.shield.limits.duplicateWindow;
  const max = global.shield.limits.duplicateMaxCount;

  if (!dup.has(key)) {
    dup.set(key, { count: 1, first: now });
    return false;
  }

  const entry = dup.get(key);
  if (now - entry.first >= win) {
    dup.set(key, { count: 1, first: now });
    return false;
  }

  entry.count++;
  if (entry.count > max) {
    addLog("DUPLICATE", `تم رصد تكرار مفرط (${entry.count}x): "${key.substring(0, 40)}..."`);
    return true;
  }
  return false;
}

// ────────────────────────────────────────────────────────────────
// تسجيل خطأ فيسبوك
// ────────────────────────────────────────────────────────────────
function registerError(err) {
  const s = global.shield;
  const msg = (err && err.message) ? err.message : String(err);

  s.errors.count++;
  s.errors.history.unshift({ time: Date.now(), msg: msg.substring(0, 120) });
  if (s.errors.history.length > 20) s.errors.history.pop();

  const banKeywords = [
    "checkpoint", "login required", "rate limit", "blocked",
    "not allowed", "session", "unauthorized", "action blocked"
  ];
  const isCritical = banKeywords.some(k => msg.toLowerCase().includes(k));

  if (isCritical) {
    addLog("CRITICAL_ERROR", `خطأ حرج: ${msg.substring(0, 80)}`);
    activateSleep(`خطأ فيسبوك حرج: ${msg.substring(0, 60)}`);
  } else if (s.errors.count >= s.limits.errorThreshold) {
    addLog("ERROR_THRESHOLD", `وصل عدد الأخطاء إلى ${s.errors.count}`);
    activateSleep(`تجاوز حد الأخطاء (${s.errors.count} أخطاء)`);
  }

  s.riskLevel = calculateRisk();
}

// ────────────────────────────────────────────────────────────────
// تفعيل وضع السكون
// ────────────────────────────────────────────────────────────────
function activateSleep(reason) {
  const s = global.shield;
  if (s.sleep.active) return;

  s.sleep.active = true;
  s.sleep.until = Date.now() + s.limits.sleepDuration;
  s.sleep.reason = reason;
  s.riskLevel = "critical";

  addLog("SLEEP_START", `وضع السكون: ${reason} (${s.limits.sleepDuration / 1000}ث)`);

  // إعادة التفعيل تلقائياً
  setTimeout(() => {
    s.sleep.active = false;
    s.sleep.reason = "";
    s.errors.count = 0;
    s.riskLevel = calculateRisk();
    addLog("SLEEP_END", "انتهى وضع السكون، البوت يعمل");
  }, s.limits.sleepDuration);
}

// ────────────────────────────────────────────────────────────────
// الدالة الرئيسية: هل يُسمح بالإرسال؟
// ────────────────────────────────────────────────────────────────
function canSend(text) {
  if (!global.shield.enabled) return { ok: true };

  resetWindows();
  const s = global.shield;

  // وضع السكون
  if (s.sleep.active) {
    const left = Math.ceil((s.sleep.until - Date.now()) / 1000);
    return { ok: false, reason: `وضع السكون نشط (${left}ث متبقية)` };
  }

  // حد الدقيقة
  if (s.stats.sentThisMinute >= s.limits.maxPerMinute) {
    addLog("RATE_LIMIT_MIN", `تجاوز حد الدقيقة: ${s.stats.sentThisMinute}/${s.limits.maxPerMinute}`);
    return { ok: false, reason: `تجاوز حد الدقيقة (${s.stats.sentThisMinute}/${s.limits.maxPerMinute})` };
  }

  // حد الساعة
  if (s.stats.sentThisHour >= s.limits.maxPerHour) {
    activateSleep(`تجاوز حد الساعة (${s.stats.sentThisHour}/${s.limits.maxPerHour})`);
    return { ok: false, reason: "تجاوز حد الساعة، وضع السكون مفعّل" };
  }

  // المحتوى المكرر
  if (text && checkDuplicate(text)) {
    return { ok: false, reason: "محتوى مكرر مفرط، تم التجاهل" };
  }

  return { ok: true };
}

// ────────────────────────────────────────────────────────────────
// تسجيل إرسال ناجح
// ────────────────────────────────────────────────────────────────
function recordSend() {
  resetWindows();
  const s = global.shield.stats;
  s.sentThisMinute++;
  s.sentThisHour++;
  s.totalSent++;
  global.shield.riskLevel = calculateRisk();
}

// ────────────────────────────────────────────────────────────────
// تثبيت النظام — يُغلّف api.sendMessage
// ────────────────────────────────────────────────────────────────
function install(api) {
  if (!api || api.__shieldInstalled) return;
  api.__shieldInstalled = true;

  const originalSend = api.sendMessage.bind(api);

  api.sendMessage = function(msg, threadID, callback, messageID) {
    const text = (typeof msg === "object") ? (msg.body || "") : (msg || "");
    const check = canSend(text);

    if (!check.ok) {
      logger(`[shield] BLOCKED — ${check.reason}`, "warn");
      if (typeof callback === "function") callback(new Error(check.reason));
      return;
    }

    // تأخير ديناميكي حسب مستوى الخطر
    const risk = global.shield.riskLevel;
    const delay = risk === "high" ? 1500 : risk === "medium" ? 800 : 200;

    setTimeout(() => {
      originalSend(msg, threadID, (err, info) => {
        if (err) {
          registerError(err);
        } else {
          recordSend();
        }
        if (typeof callback === "function") callback(err, info);
      }, messageID);
    }, delay);
  };

  addLog("INSTALL", "تم تثبيت نظام الدرع بنجاح");
  logger("[shield] Anti-Ban Shield installed ✅", "shield");
}

// ────────────────────────────────────────────────────────────────
// إيقاظ يدوي لوضع السكون
// ────────────────────────────────────────────────────────────────
function forceWake() {
  const s = global.shield;
  s.sleep.active = false;
  s.sleep.reason = "";
  s.errors.count = 0;
  s.riskLevel = calculateRisk();
  addLog("FORCE_WAKE", "تم إيقاظ البوت يدوياً");
}

module.exports = {
  install,
  canSend,
  registerError,
  activateSleep,
  forceWake,
  recordSend,
  addLog,
  calculateRisk
};
